function snr = SNR(signal,ts,idx,psi)
% Calculates the SNR metric of a signal
% Input:
%   signal  --  a column vector of signal from multiple historical units
%   ts  --  corresponding time points
%   idx  --  corresponding unit index
%   psi  --  polynomial basis
% Output:
%   snr  --  SNR of the signal

n = max(idx);
R = zeros(n,1);
res = R; l = R;
for i = 1:n
    ni = sum(idx == i);
    L = signal(idx == i);
    R(i) = L(end) - L(1);
    Psi = design_matrix(ts(idx==i),psi);
    ci = reswt(ts(idx==i));
    H=ci*Psi*inv(Psi'*ci*ci*Psi)*Psi'*ci; % projection matrix
    res(i) = L' * ci * (eye(ni) - H) * ci * L;
    l(i) = L(end);
end

R_sq = (mean(R))^2;
sigma_sq = mean(res);
nu = var(l);

snr = R_sq/(sigma_sq + nu);