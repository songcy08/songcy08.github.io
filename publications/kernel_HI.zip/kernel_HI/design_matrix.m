function Psi=design_matrix(obs,psi)
% Generate the design matrix
% Input:
%   Obs  --  the time points to generate design matrix
%   psi  --  polynomial basis
% Output:
%   Psi  --  the design matrix

if size(obs,2)>1
    obs=obs';
end
assert(size(obs,2)==1);
p = length(psi);
Psi=ones(length(obs), p); % design matrix
for j=1: p
    Psi(:,j)=obs.^psi(j);
end