function y=init_params(kernel_name, n_sensor, degree, gamma, C)
% This function initialize the kernel parameters
% 1. linear: u'v
% 2. polynomial: (C+gamma*u'*v)^degree
% 3. sigmoid: tanh(gamma*u'*v+C)
% 4. radial basis: exp(-gamma*|u-v|^2)

% Input:
%   kernel_name    --  currently I offer 4 options: 'linear', 'polynomial', 'sigmoid', 'radial basis'
%   n_sensor    --  number of sensors used in the fusion
%   degree, gamma, C    --  see above
% Output:
%   y    --  a structure used by the function kernel

if nargin<5
    y.C=0;
else
    y.C=C;
end

if nargin<2
    y.n_sensor=11;
else
    y.n_sensor=n_sensor;
end

if nargin<4
    y.gamma=1/y.n_sensor;
else
    y.gamma=gamma;
end

if nargin<3
    y.degree=3;
else
    y.degree=degree;
end
    
if nargin<1
    y.function='gaussian';
else
    y.function=kernel_name;
end