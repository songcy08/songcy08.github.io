function Y=kernel(x1, x2, params)
% This function calculate the kernel matrix given two matrices
% Input:
%   x1, x2    --  input matrices, each row is a vector
%   params    --  parameters, struct
% Output:
%   Y    -- a matrix. Y(i,j) is evaluated at the ith row of x1 and jth row
%             of x2
assert(size(x1,2)==size(x2,2));
if nargin<3
    params=init_params('gaussian',size(x1,2));
end

if strcmp(params.function, 'linear')
    Y=x1*x2';
elseif strcmp(params.function, 'polynomial')
    Y=(params.C+params.gamma*x1*x2').^params.degree;
elseif strcmp(params.function, 'sigmoid')
    Y=tanh(params.gamma*x1*x2'+params.C);
elseif strcmp(params.function, 'gaussian')
    tmp1=repmat(sum(x1.^2,2), 1, size(x2,1));
    tmp2=repmat(sum(x2.^2,2)', size(x1,1),1);
    Y=tmp1+tmp2-2*x1*x2';
    Y=exp(-params.gamma*Y);
else
    Y=zeros(size(x1,1),size(x2,1));
end