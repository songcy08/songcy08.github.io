function rld = rldtraining( signals, idx, ts, psi )
% This function implement the in-situ RLD model proposed by Gebraeel,
% estimating the essential parameters in the training data

% Input:
%   signals    --  a column vector, the concatenated signal sequence from multiple units
%   idx    --  a column vector of same length as signals, specifying the
%                  which unit a value in signals corresponds to
%   ts    --  corresponding time points
%   psi    --  polynomial basis
% Output:
%   rld    --  a structure containing parameters of the model
% fit a polynomial model
p = length(psi);
n_unit=max(idx);
theta=zeros(n_unit, p);
lastObs=zeros(n_unit,1);
noisevar=zeros(n_unit,1);
for i=1:n_unit
    signal=signals(idx==i);
    Psi=design_matrix(ts(idx==i),psi);
    theta(i,:)=wtlm(Psi,signal,ts(idx==i))';
    lastObs(i)=signal(end);
    singlenoise=signal-Psi*theta(i,:)';
    noisevar(i)=sum(singlenoise.^2)/(length(signal)-p);
end

rld.mu=mean(theta,1)';
rld.sigma=cov(theta);
rld.psi=psi;
rld.ud=mean(lastObs);
rld.vd=var(lastObs);
rld.noisevar=mean(noisevar);
rld.trend=sign(rld.mu(end));
end

