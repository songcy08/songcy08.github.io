function beta=wtlm(X,y,ts)
% weighted linear regression
c = reswt(ts);
beta=(X'*c*c*X)\(X'*c*c*y);