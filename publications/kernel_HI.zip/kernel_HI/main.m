% Import data
clear; clc;
disp('Processing data');
trRaw=dlmread('Engine_sim_data/train_FD001.txt');
trSet.Idx = trRaw(:,1); trSet.Ts = trRaw(:,2); trSet.Raw = trRaw(:,3:end);
tsRaw=dlmread('Engine_sim_data/test_FD001.txt');
tsSet.Idx = tsRaw(:,1); tsSet.Ts = tsRaw(:,2); tsSet.Raw = tsRaw(:,3:end);
tsSet.RUL=dlmread('Engine_sim_data/RUL_FD001.txt');
colnames={'altitudes','Mach','sea-level(temperatures)',...
    'T2','T24','T30','T50','P2','P15','P30','Nf','Nc','epr','Ps30','phi','NRf','NRc',...
    'BPR','farB','htBleed','Nf_dmd','PCNfR_dmd','W31','W32'};

% select sensors
sensor_idx=[5,7,10,11,14,15,16,18,20,23,24]; % these sensors are selected by Liu
trSet.L = trSet.Raw(:,sensor_idx);
tsSet.L = tsSet.Raw(:,sensor_idx);
sensor_trend=[1, 1, -1, 1, 1, -1, 1, 1, 1, -1, -1]; % sensors that have a trend
ntr_units=max(trSet.Idx);
nts_units=max(tsSet.Idx);

% standardize training data
[trSet.L, mu, sigma]=zscore(trSet.L.*repmat(sensor_trend, size(trSet.L,1), 1));
for i=1:ntr_units
    idx = trSet.Idx == i;
    tmp=trSet.L(idx,:);
    tmp=min(tmp,[],1)-exp(tmp(1,:));
    trSet.L(idx,:)=trSet.L(idx,:)-repmat(tmp,sum(idx),1);
end
trSet.L = log(trSet.L);
trSet.L = trSet.L.*repmat(sensor_trend,size(trSet.L,1),1); % trend changes back

% standardize testing data
tsSet.L=(tsSet.L.*repmat(sensor_trend, size(tsSet.L,1),1)...
    -repmat(mu,size(tsSet.L,1),1))./repmat(sigma,size(tsSet.L,1),1);
for i=1:nts_units
    idx = tsSet.Idx == i;
    tmp = tsSet.L(idx,:);
    tmp = min(tmp,[],1)-exp(tmp(1,:));
    tsSet.L(idx,:)=tsSet.L(idx,:)-repmat(tmp,sum(idx),1);
end
tsSet.L = log(tsSet.L);
tsSet.L = tsSet.L.*repmat(sensor_trend, size(tsSet.L,1) ,1);

% the SNR-HI method
SNR(trSet.L(:,4),trSet.Ts,trSet.Idx,[0,1,2])
[wt,SNR] = snr_fusion(trSet,[0,1,2])

% calculate the matrices
params.p = 3; % degree of the regression model
params.psi = [0,1,2];
par = init_params('polynomial'); 
par.gamma=1; par.C=0.5; par.degree=2;
[beta,kSNR] = kernel_fusion(trSet,params,par); % this step requires large RAM

% calculate health index for training and testing data
trKernelHI=kernel(trSet.L, trSet.L, par) * beta;
tsKernelHI=kernel(tsSet.L, trSet.L, par) * beta;
lastIdx = find(diff([trSet.Idx;max(trSet.Idx)+1]) > 0);
firstIdx = find(diff([0;trSet.Idx]) > 0);
multiplier = 2 /(mean(trKernelHI(lastIdx)) - mean(trKernelHI(firstIdx)));
trKernelHI = trKernelHI * multiplier;
tsKernelHI = tsKernelHI * multiplier;

% testing
pred_life=zeros(nts_units,1);
Err = zeros(nts_units,1);
rld=rldtraining(trKernelHI,trSet.Idx, trSet.Ts, params.psi);
for j=1:nts_units
    idx = tsSet.Idx == j;
    pred_life(j)=rldpredict(tsKernelHI(idx),tsSet.Ts(idx),rld,true);
    Err(j) = abs(pred_life(j) - tsSet.RUL(j))/(tsSet.RUL(j)+max(tsSet.Ts(idx)));
end

RULlevels=[max(tsSet.RUL), 100, 80, 60, 40, 20];
ErrMean=zeros(length(RULlevels),size(Err,2));
for i=1:length(RULlevels)
    idx=tsSet.RUL<=RULlevels(i);
    ErrMean(i,:)=mean(Err(idx,:),1);
end