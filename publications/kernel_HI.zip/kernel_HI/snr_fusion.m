function [wt,SNR] = snr_fusion(trSet,psi)
% Estimate the fusion coefficient of the SNR HI method
% Input:
%   trSet  --  training dataset
%   psi  --  polynomial basis
% Output:
%   wt  --  estimated fusion coefficients
%   SNR  --  the SNR of the estimated health index

ntr_units = max(trSet.Idx);
A=ones(ntr_units)/ntr_units^2;
D=(eye(ntr_units)-ones(ntr_units)./ntr_units)/(ntr_units-1);
B=cell(ntr_units,1);
for i=1:ntr_units
    idx = trSet.Idx == i;
    ni = sum(idx);
    Psi=design_matrix(trSet.Ts(idx),psi); % design matrix
    ci=reswt(trSet.Ts(idx)); % error weight
    H=ci*Psi*inv(Psi'*ci*ci*Psi)*Psi'*ci; % projection matrix
    B{i}=ci*(eye(ni)-H)*ci/ntr_units;
end

firstObs=zeros(ntr_units, size(trSet.L,2));
lastObs=zeros(ntr_units, size(trSet.L,2));
for i=1:ntr_units
    tmp=trSet.L(trSet.Idx==i,:);
    firstObs(i,:)=tmp(1,:);
    lastObs(i,:)=tmp(end,:);
end

Apie=(lastObs-firstObs)'*A*(lastObs-firstObs);
Bpie=lastObs'*D*lastObs;
for i=1:ntr_units
    Bpie=Bpie+trSet.L(trSet.Idx==i,:)'*B{i}*trSet.L(trSet.Idx==i,:);
end
[wt, ~]=eigs(Apie, Bpie, 1);
wt=wt/sum(abs(wt));
SNR=(wt' * Apie *wt)/(wt' * Bpie *wt);