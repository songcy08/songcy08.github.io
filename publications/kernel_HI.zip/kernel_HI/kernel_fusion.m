function [beta,kSNR] = kernel_fusion(dataset,params,par)
% Calculate beta in the kernel HI method
% Input:
%   dataset  --  the training dataset
%   params  --  model parameters
%   par  --  kernel parameters

ntr_units = max(dataset.Idx);
A=ones(ntr_units)/ntr_units^2;
D=(eye(ntr_units)-ones(ntr_units)./ntr_units)/(ntr_units-1);
B=cell(ntr_units,1);
for i=1:ntr_units
    idx = dataset.Idx == i;
    Psi=design_matrix(dataset.Ts(idx),params.psi); % design matrix
    ci=reswt(dataset.Ts(idx)); % error weight
    H=ci*Psi*inv(Psi'*ci*ci*Psi)*Psi'*ci; % projection matrix
    B{i}=ci*(eye(sum(idx))-H)*ci/ntr_units;
end

firstObs=zeros(ntr_units, size(dataset.L,2));
lastObs=zeros(ntr_units, size(dataset.L,2));
for i=1:ntr_units
    tmp=dataset.L(dataset.Idx==i,:);
    firstObs(i,:)=tmp(1,:);
    lastObs(i,:)=tmp(end,:);
end

J=kernel(lastObs, dataset.L, par);
Q=J-kernel(firstObs, dataset.L, par);
Fbar=J' * D *J;
for i=1:ntr_units
    Ki=kernel(dataset.L(dataset.Idx==i,:), dataset.L, par);
    Fbar=Fbar+Ki' * B{i}  * Ki;
end
Abar=Q' * A *Q;

% Ensure the matrices are symmetric
Abar = (Abar+Abar')/2;
Fbar = (Fbar+Fbar')/2;
epsilon=1e-4;
FFbar=Fbar+epsilon*eye(size(Fbar));
opt.MAXIT=1e10; opt.MAXEIG=1;
[kSNR,Beta]=eigifp(Abar,FFbar,opt);
beta=real(Beta)/sum(real(Beta).^2)*length(Beta); % avoid too small values