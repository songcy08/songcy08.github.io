import numpy as np
import scipy as sp
import sklearn as sk
import sklearn.linear_model as skl
import sklearn.decomposition as skd
import matplotlib.pyplot as mp

def infbs_induce(x,knots,M,n):
    """
    This function helps to generate B-splines
    Input:
        x - a vector of time points to generate B-splines
        knots - a vector of knots
        M - generated B-splines at degree n-1
        n - degree
    Output:
        newM - generated B-splines at degree n
    """
    k = np.size(knots)
    assert(n <= k)
    newM = np.zeros((np.size(x), k+n+1))
    C0 = C1 = (knots[k-1] - knots[0])/(k-1)
    newM[:,0] = (knots[0] - x)/C0 * M[:,0]
    for j in range(1,n):
        newM[:,j] = M[:,j-1] + (knots[j] - x) / C0 * M[:,j]
    j = n
    if k > n:
        newM[:,j] = M[:,j-1] + (knots[j] - x)/(knots[j] - knots[j - n]) * M[:,j]
    elif k == n:
        newM[:,j] = M[:,j-1] + M[:,j]
    for j in range(n + 1, k):
        newM[:,j] = (x - knots[j-n-1])/(knots[j-1] - knots[j-n-1]) * M[:,j-1] + (knots[j] - x)/(knots[j] - knots[j-n]) * M[:,j]
    j = k
    if k > n:
        newM[:,j] = M[:,j] + (x - knots[j-n-1])/(knots[j-1]-knots[j-n-1]) * M[:,j-1]
    elif k == n:
        newM[:,j] = M[:,j-1] + M[:,j]
    for j in range(k + 1, k + n):
        newM[:,j] = (x - knots[j-n-1])/C1 * M[:,j-1] + M[:,j]
    j = k + n
    newM[:,j] = (x - knots[j-n-1]) / C1 * M[:,j-1]
    return newM

def infbs(x,knots,degree):
    """
    This function generates B-splines basis
    Input:
        x - a vector of time points to generate B-splines
        knots - a vector of knots
        degree - degree of B-spline
    Output:
        M - generated B-splines
    """
    M = np.zeros((np.size(x),np.size(knots) + 1))
    ex_knots = np.append(np.insert(knots, 0, -np.inf), np.inf)
    for i in range(np.size(knots) + 1):
        M[:,i] = np.logical_and(x < ex_knots[i + 1], x >= ex_knots[i]).astype(float)
    
    if degree == 0:
        return M
    for i in range(1,degree+1):
        M = infbs_induce(x,knots,M,i)
    return M

def der_infbs(x,knots,degree,der):
    """
    This function generates derivates of B-splines basis
    Input:
        x - a vector of time points to generate derivatives of B-splines
        knots - a vector of knots
        degree - degree of B-spline
        der - the order of derivative to generate
    Output:
        M - generated B-splines
    """
    k = np.size(knots)
    n = degree
    assert(n <= k)
    if der == 0:
        return infbs(x,knots,n)
    
    M = der_infbs(x,knots,n - 1,der - 1)
    newM = np.zeros((np.size(x), k+n+1))
    C0 = C1 = (knots[k-1] - knots[0])/(k-1)
    for j in range(0,n):
        newM[:,j] = - n/C0 * M[:,j]
    if n==k:
        newM[:,n] = 0
    elif n >= 1:
        newM[:,n] = - n/(knots[n] - knots[0]) * M[:,n] 
        for j in range(n + 1, k):
            newM[:,j] = n/(knots[j-1] - knots[j-n-1]) * M[:,j-1] - n/(knots[j]-knots[j-n]) * M[:,j]
        newM[:,k] = n/(knots[k-1] - knots[k-n-1]) * M[:,k-1]
    else:
        newM[:,0] = - M[:,0]
        for j in range(1,k):
            newM[:,j] = M[:,j-1] - M[:,j]
        newM[:,k] = M[:,k-1]
    for j in range(k + 1, k + n + 1):
        newM[:,j] = n/C1 * M[:,j-1]
    return newM
    

def fit_infbs(X,y,degree,impose_mono=True):
    """
    This function fit B-splines
    Input:
        X - a matrix of B-spline basis
        y - a vector of response
        degree - the degree of the B-spline
        impose_mono - do we require the spline to be monotone?
    Output:
        beta - fitting results for the basis functions
    """
    beta = dict()
    rg = skl.LinearRegression(fit_intercept=False)
    rg.fit(X,y)
    if not impose_mono:
        beta['coef'] = rg.coef_
    else:
        n = degree
        d = np.shape(X)[1]
        A = np.eye(d - 2*n)
        A[1:(d-2*n),1:(d-2*n)] = -np.eye(d-2*n-1)
        lb = np.array([-np.inf] * (n+1) + [0] * (d-n-1))
        ub = np.array([0]*n + [np.inf] * (d-n))
        A = sp.linalg.block_diag(np.eye(n), A, np.eye(n))
        beta['ub'] = ub
        beta['lb'] = lb
        beta['A'] = A
        # if monotonicity is imposed:
        if all(A @ rg.coef_ >= lb) and all(A @ rg.coef_ <= ub):
            beta['coef'] = rg.coef_
        else:
            par = sp.optimize.minimize(fun = lambda beta: np.sum((y - X @ beta) ** 2), x0 = np.zeros(np.shape(X)[1]), method = 'trust-constr', jac = lambda beta: -2 * X.T @ (y - X @ beta), hess = lambda beta: 2 * X.T @ X, constraints = sp.optimize.LinearConstraint(A,lb,ub))
            beta['coef'] = par.x
    
    beta['sigma_sq'] = np.sum((y - X @ beta['coef']) ** 2) / (len(y) - X.shape[1])
    beta['var'] = beta['sigma_sq'] * np.linalg.inv(X.T @ X)
    beta['BIC'] = X.shape[1]*np.log(len(y)) + len(y) * np.log(beta['sigma_sq']*(len(y) - X.shape[1])/len(y))
    return beta

def fit_signal(l,degree=2,nknots=2,impose_mono=True,trend=None):
    """
    This function fits a signal
    Input:
        Ts - Time points for the signal
        y - the signal
        nknots - number of knots to generate B-splines
        degree - the degree of the B-spline
        impose_mono - do we require the signal to be monotone?
        trend - whether the signal is increasing (1) or decreasing (-1)
    Output:
        beta - the fitting results for the basis functions
    """
    Ts = l.index.get_level_values('time').to_numpy()
    y = l.to_numpy()
    if trend is None:
        trend = detect_trend(Ts,y)
    if trend == 0:
        trend = 1

    knots = np.linspace(Ts.min(),Ts.max(),nknots+2)[1:(nknots+1)]
    M = infbs(Ts, knots, degree)
    beta = fit_infbs(M, trend * y, degree, impose_mono)
    beta['coef'] = trend * beta['coef']
    beta['knots'] = knots
    beta['base'] = 'spline'
    beta['degree'] = degree
    return beta

def fit_signal_BIC(l,degree=2,max_nknots=10,impose_mono=True,trend=None):
    """
    This function fits a signal
    The number of knots to generate B-splines is determined by BIC
    Input:
        l - Pandas series, the signal with time as index
        degree - the degree of the B-spline
        max_nknots - maximum number of knots to consider
        impose_mono - do we require the signal to be monotone?
        trend - whether the signal is increasing (1) or decreasing (-1)
    Output:
        beta - the fitting results for the basis functions
    """
    Ts = l.index.get_level_values('time').to_numpy()
    y = l.to_numpy()
    if trend is None:
        trend = detect_trend(Ts,y)
    if trend == 0:
        trend = 1

    # find optimal K
    max_nknots = np.amin(np.array([max_nknots, l.size-4-degree]))
    Ks = np.arange(degree, max_nknots+1)
    BIC = np.zeros(Ks.size)
    knots = [0] * Ks.size
    betas = [0] * Ks.size
    for n in range(Ks.size):
        nknots = Ks[n]
        knots[n] = np.linspace(Ts.min(),Ts.max(),nknots+2)[1:(nknots+1)]
        M = infbs(Ts, knots[n], degree)
        betas[n] = fit_infbs(M, trend * y, degree, impose_mono)
        BIC[n] = betas[n]['BIC']
    
    idx = np.argmin(BIC)
    #print(nknots_opt)
    beta = dict(coef = trend * betas[idx]['coef'], knots = knots[idx], base = 'spline', degree = degree)
    return beta

def detect_trend(Ts,L,condition=None):
    """
    This function detects the trend of a signal: increaisng or decreasing
    Input:
        Ts - Time points for the signal
        L - the signal
    Output:
        whether the signal is increasing (1) or decreasing (-1)
    """
    rg = skl.LinearRegression()
    Ts = np.reshape(Ts, (-1,1))
    if condition is not None:
        cond = get_factor_matrix(condition)
    else:
        cond = np.zeros((Ts.size, 0))
    rg.fit(np.hstack((Ts,cond)), L)
    return np.sign(rg.coef_[0])

def get_der_feature(Ts, beta, ders = [0, 1, 2]):
    """
    This function obtain the derivatives as features
    Input:
        Ts - Time points to obtain features
        beta - the fitted coefficients using B-splines for the signal
        ders - orders of the derivatives to calculate
    Output:
        F - obtained features
    """
    F = np.zeros((np.size(Ts), len(ders)))
    for i in range(len(ders)):
        M = der_infbs(Ts, beta['knots'], beta['degree'], ders[i])
        F[:,i] = M @ beta['coef']
    return F

def get_covariates(ts, ts_betas, tr_betas, features, ts_idx, scale = True):
    """
    This function is convenient wrapper to obtain features
    Input:
        ts - the dictionary containing testing units
        ts_betas - ts_betas[i][j] is the fitted coefficients of B-splines for testing unit i, sensor j
        tr_betas - similar as ts_betas, but for training units
        features - orders of the derivatives to calculate
        ts_idx - we only consider one testing unit specified by ts_idx
    Output:
        xs - obtained features for testing units ts_idx
        xr - obtained features from trainig units corresponding to testing unit ts_idx
    """
    n_sensor = len(tr_betas[0])
    ntr_units = len(tr_betas)
    xs = np.zeros((n_sensor, len(features)))
    tau = ts.loc[ts_idx].index.get_level_values('time').max()
    for j in range(n_sensor):
        xs[j,:] = get_der_feature(tau, ts_betas[ts_idx][j], ders = features)
    xr = np.zeros((ntr_units,n_sensor,len(features)))
    for k in range(ntr_units):
        for j in range(n_sensor):
            xr[k,j,:] = get_der_feature(tau, tr_betas[k][j], ders = features)
    if scale:
        xs = (xs - xr.mean(axis=0))/xr.std(axis=0)
        xr = (xr - xr.mean(axis=0))/xr.std(axis=0)
    return (xs, xr)

def fit_lm(x,y,weight = None,intercept = True):
    """
    This function fits weighted linear regression
    Input:
        x - input
        y - response
        weight - a vector of weights for each observation
        intercept - do we need an intercept term
    Output:
        a dictionary
    """
    if intercept:
        x = np.hstack((np.ones((x.shape[0],1)),x))
    if weight is None:
        weight = np.ones(x.shape[0])
    assert(weight.size == x.shape[0])
    K = np.diag(weight)
    H = np.linalg.inv(x.T @ K @  x)
    coef = H @ x.T @ K @ y
    res = y - x @ coef
    dof = np.trace(K) - np.trace(H @ x.T @ (K ** 2) @ x)
    sigma2 = res.T @ K @ res / dof
    coef_cov = sigma2 * (H @ x.T @ (K ** 2) @ x @ H)
    m = dict(data_x = x.copy(), data_y = y.copy(), coef = coef, noisevar = sigma2, coef_cov = coef_cov, intercept = intercept, weight = weight, fitted = x @ coef)
    return m

def predict_lm(lm, newx):
    """
    This function does prediction for weighted linear regression
    Input:
        lm - output of fit_lm function
        newx - new data
    Output:
        pred - a dictionary of prediction results
    """
    lm['new_x'] = newx
    if lm['intercept']:
        newx = np.hstack((np.ones((newx.shape[0], 1)), newx))
    muhat = yhat = newx @ lm['coef']
    muhat_var = newx @ lm['coef_cov'] @ newx.T
    yhat_var = muhat_var + lm['noisevar']
    pred = dict(mu = muhat, mu_var = muhat_var, y = yhat, y_var = yhat_var)    
    return pred

def distance(x1, x2, metric='euclidean'):
    """
    This function conducts knn
    Input:
        x1 - a row vector of the testing data
        x2 - a matrix of the training data
        rescale - the scale vector
        metric - how to define distance
    Output:
        distance - the distance vector
        
        distance(i) = Sum_j: (x1[j] - x2[i,j])^2 / rescale[j]
    """
    if(len(x1.shape) == 1):
        x1 = np.reshape(x1, (1,-1))
    assert(x1.shape[1] == x2.shape[1])
    d = sk.metrics.pairwise_distances(x1,x2,metric)
    d = np.squeeze(d)
    return d

def kernel(name='Uniform',bandwidth=None,bandtype='knn'):
    kn = dict(name = name, bandwidth = bandwidth, bandtype = bandtype)
    return kn

def get_kernel_par(kn, distance=None):
    if kn['bandtype'] == 'knn':
        lmd = np.sort(distance)[kn['bandwidth']-1]
    else:
        lmd = kn['bandwidth']
    return(lmd)

def get_unit_weight(kn, distance):
    lmd = get_kernel_par(kn,distance)
    if kn['name'] == 'Uniform':
        wt = distance <= lmd
        return wt.astype(float)
    if kn['name'] == 'Gaussian':
        return(np.exp(-distance ** 2)/lmd ** 2)
    if kn['name'] == 'Triangular':
        return(np.maximum(1-distance/lmd, 0))
    if kn['name'] == 'Parabolic':
        return(np.maximum(1-distance**2/lmd**2,0))

def single_sensor_predict(xs, xr, trLife, kernel, details=True):
    """
    Single sensor module
    Input:
        xs - sensor * feature matrix
        xr - unit * sensor * feature array
        trLife - historical units failure time
        kernel - kernel function
    Output: 
        predicted failure time
    """
    xs = np.reshape(xs, (1,-1))
    dist = distance(xs, xr)
    wts = get_unit_weight(kernel, dist)
    if(np.sum(wts) < 1e-10):
        return dict(pred = -np.inf, predvar = np.inf, lm=None)
    lm = fit_lm(xr, trLife, wts)
    y = predict_lm(lm, xs)
    if details:
        return dict(pred = y['mu'], predvar = y['y_var'], lm = lm)
    else:
        return y['mu']

def get_sensor_weight(predvar, min_q=None, var_power=1):
    n_sensor = predvar.size
    if min_q is None:
        min_q = n_sensor
    wt = np.zeros(n_sensor)
    bindwidth = np.sort(predvar)[min_q-1]
    idx = predvar <= bindwidth
    wt[idx] = (1 / predvar[idx]) ** var_power
    return(wt)

def multi_sensor_predict(xs, xr, trLife, kns):
    """
    Apply single sensor module to each sensor
    Input:
        xs - sensor * feature matrix
        xr - unit * sensor * feature array
        trLife - historical units failure time
        kns - kernel function for each sensor in single sensor module
    Output: 
        pred - predicted failure time and prediction variance
    """
    assert(len(xr.shape) == 3)
    xs = np.squeeze(xs)
    assert(len(xs.shape) == 2)
    assert(xs.shape == xr.shape[1:3])
    n_sensor = xs.shape[0]
    pred = np.zeros(n_sensor)
    predvar = np.zeros(n_sensor)
    for j in range(n_sensor):
        cur_xs = np.reshape(xs[j,:], (1,-1))
        cur_xr = xr[:,j,:]
        result = single_sensor_predict(cur_xs, cur_xr, trLife, kns[j])
        pred[j] = result['pred']
        predvar[j] = result['predvar']
    predvar[predvar < 0] = np.inf
    return (pred,predvar)

def decision_fusion(xs, xr, trLife, kns, min_q=None, var_power=1):
    """
    Weighted average of the predicted failure time across different sensors
    Input:
        xs - sensor * feature matrix
        xr - unit * sensor * feature array
        trLife - historical units failure time
        kns - kernel function for each sensor in single sensor module
        min_q - how many sensors to consider
        var_power - we use prediction variance to weight each sensor
    Output: 
        pred - predicted failure time for testing units
    """
    (pred,predvar) = multi_sensor_predict(xs, xr, trLife, kns)
    wt = get_sensor_weight(predvar, min_q, var_power)
    return np.sum(wt * pred) / np.sum(wt)

def overall_weights(xs, xr, predvar, kn, min_q=None):
    (ntr_units, n_sensor, n_feature) = xr.shape
    sensor_weights = get_sensor_weight(predvar, min_q, var_power=1)
    sensor_weights = sensor_weights / np.sum(sensor_weights)
    scale = np.reshape(sensor_weights ** 0.5, (-1,1))
    dist = distance(np.reshape(xs*scale,(1,-1)), np.reshape(xr*scale,(ntr_units,n_sensor*n_feature)))
    unit_weights = get_unit_weight(kn, dist)
    return (sensor_weights,unit_weights)

def feature_fusion(xs, xr, trLife, kns, kn, min_q = None, nprime = 15, details=True):
    """
    Given parameters, reduce the dimension of the data and fit the LLR
    Input:
        xs - sensor * feature matrix
        xr - unit * sensor * feature array
        trLife - historical units failure time
        kns - kernel function for each sensor in single sensor module
        kn - kernel function for the fused features
        min_q - how many sensors to consider for PCA
        nprime - number of nearest historical units to consider for PCA
    Output: 
        pred - predicted failure time for testing units
    """
    (ntr_units, n_sensor, n_feature) = xr.shape
    (pred,predvar) = multi_sensor_predict(xs, xr, trLife, kns)
    kernel1 = kernel('Uniform',bandwidth=nprime)
    (sensor_weights, unit_weights) = overall_weights(xs, xr, predvar, kernel1, min_q)
    txr = np.zeros((ntr_units, n_feature))
    txs = np.zeros((1,n_feature))
    for f in range(n_feature):
        pca = skd.PCA(n_components=1)
        tmpxr = xr[...,f][:,sensor_weights > 0]
        tmpxs = np.reshape(xs[...,f][sensor_weights > 0],(1,-1))
        pca.fit(tmpxr[unit_weights > 0])
        txr[:,f] = np.squeeze(pca.transform(tmpxr))
        txs[0,f] = pca.transform(tmpxs)
    return single_sensor_predict(txs, txr, trLife, kn, details)

def get_err(Errs, ts_RUL,levels=None):
    """
    This function obtains average error for each level of RUL
    Input:
        Errs - prediction error for each testing unit
        ts_RUL - true RULs of the testing units
        levels - levels of RUL to average
    Output: 
        Err - averaged prediction error at each level of RUL
    """
    if levels is None:
        levels = np.array([np.inf,100,80,60,40,20])
    Err = np.zeros(levels.size)
    for i in range(levels.size):
        idx = ts_RUL <= levels[i]
        Err[i] = np.mean(Errs[idx])
    return Err

