# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 19:01:26 2020

@author: Changyue Song
"""

import numpy as np
import func as fc
import multiprocessing as mpc
import pandas as pd

#%% preprocessing
data_folder = '../../Datasets/aircraft engine'
data_num = '1'
tr = pd.read_table(data_folder + '/train_FD00' + data_num + '.txt', sep = ' ', header=None)
tr = tr.iloc[:,0:26]
tr.iloc[:,0] = tr.iloc[:,0] - 1
ts = pd.read_table(data_folder + '/test_FD00' + data_num + '.txt', sep = ' ', header=None)
ts = ts.iloc[:,0:26]
ts.iloc[:,0] = ts.iloc[:,0] - 1
ts_RUL = np.genfromtxt(data_folder + '/RUL_FD00' + data_num + '.txt', delimiter = ' ')
colnames = np.array(['altitudes','Mach','sea-level(temperatures)','T2','T24','T30','T50','P2','P15','P30','Nf','Nc','epr','Ps30','phi','NRf','NRc','BPR','farB','htBleed','Nf_dmd','PCNfR_dmd','W31','W32'])
tr.columns = ['unitIdx','time'] + colnames.tolist()
ts.columns = ['unitIdx','time'] + colnames.tolist()
tr = tr.set_index(['unitIdx','time'])
ts = ts.set_index(['unitIdx','time'])

# transform data
ntr_units = tr.index.get_level_values('unitIdx').max() + 1
nts_units = ts.index.get_level_values('unitIdx').max() + 1

# sensor selection
sensor_selector = tr.std(axis=0) > 0.01 # exclude constant signals
sensor_selector[['altitudes','Mach','sea-level(temperatures)']] = False # exclude the first three signals
sensor_selector['T2'] = False # exclude T2
sensor_selector['P15'] = False # exclude P15
selected_sensor = colnames[sensor_selector]
tr = tr[selected_sensor]
ts = ts[selected_sensor]
n_sensor = np.size(selected_sensor)
# obtain failure time
trLife = tr.groupby(level = 'unitIdx').tail(1).index.get_level_values(1).to_numpy()
tsLife = ts.groupby(level = 'unitIdx').tail(1).index.get_level_values(1).to_numpy() + ts_RUL

#%% spline fit
# first, fit all training and testing unit signals
tr_betas = [[0] * n_sensor for i in range(ntr_units)]
if __name__ == '__main__':
    pool = mpc.Pool(mpc.cpu_count() - 1)
    for i in range(ntr_units):
        for j in range(n_sensor):
            tr_betas[i][j] = pool.apply_async(fc.fit_signal_BIC, args = (tr.loc[i,selected_sensor[j]],))
    pool.close()
    pool.join()
tr_betas = [[tr_betas[i][j].get() for j in range(n_sensor)] for i in range(ntr_units)]

ts_betas = [[0] * n_sensor for i in range(nts_units)]
if __name__ == '__main__':
    pool = mpc.Pool(mpc.cpu_count() - 1)
    for i in range(nts_units):
        for j in range(n_sensor):
            ts_betas[i][j] = pool.apply_async(fc.fit_signal_BIC, args = (ts.loc[i,selected_sensor[j]],))
    pool.close()
    pool.join()
ts_betas = [[ts_betas[i][j].get() for j in range(n_sensor)] for i in range(nts_units)]

#%% Single sensor module
kn = fc.kernel('Uniform',bandwidth = 15)
kns = [kn] * n_sensor
single_pred = np.zeros((nts_units, n_sensor))
single_predvar = single_pred.copy()

for i in range(nts_units):
    (xs, xr) = fc.get_covariates(ts, ts_betas, tr_betas, features = [0,1,2], ts_idx = i)
    (single_pred[i], single_predvar[i]) = fc.multi_sensor_predict(xs, xr, trLife, kns)
        
#%% Prediction: Data level fusion
tsLifehat1 = np.zeros(nts_units)
for i in range(nts_units):
    (xs, xr) = fc.get_covariates(ts, ts_betas, tr_betas, features = [0,1,2], ts_idx = i)
    tsLifehat1[i] = fc.decision_fusion(xs, xr, trLife, kns, min_q = 5, var_power = 1)

Errs1 = np.divide(np.abs(tsLifehat1 - tsLife), tsLife)
Err1 = fc.get_err(Errs1, ts_RUL)

#%% Prediction: feature level fusion
tsLifehat2 = np.zeros(nts_units)
for i in range(nts_units):
    (xs,xr) = fc.get_covariates(ts, ts_betas, tr_betas, features = [0,1,2], ts_idx = i)
    tsLifehat2[i] = fc.feature_fusion(xs, xr, trLife, kns, kn, min_q = 5, nprime = 15, details=False)
    
Errs2 = np.divide(np.abs(tsLifehat2 - tsLife), tsLife)
Err2 = fc.get_err(Errs2, ts_RUL)
