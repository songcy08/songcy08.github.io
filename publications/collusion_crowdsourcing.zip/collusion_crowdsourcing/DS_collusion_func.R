# The Dawid-Skene model can be treated more efficiently

# log likelihood
logLik.DS = function(md, tL, marginL = NULL){
  if(is.null(marginL))  marginL = ind_pair_prob(md, tL, which = 'marginL')$marginL
  marginL_eq = t(apply(marginL, MARGIN = 1, FUN = diag))
  marginL = t(apply(marginL, MARGIN = 1, FUN = function(x) x[row(x) != col(x)]))
  result = sum(log(rowSums(marginL_eq) * (1 - md$H) + md$H) * tL$total_eq, na.rm = TRUE) + sum(log(marginL * (1 - md$H)) * tL$count_uneq, na.rm = TRUE)
  return(result)
}

# calculate probabilities for a pair of independent workers
ind_pair_prob = function(md, tL, which = 'Lcond'){
  a1 = with(tL, array(md$a[worker1,,], dim = c(npair,C,C,C)))
  # a1[k,y,l1,l2] = probability the first worker in pair k gives label l1 when true label y
  a2 = with(tL, array(md$a[worker2,,], dim = c(npair,C,C,C))) 
  # a2[k,y,l2,l1] = probability the second worker in pair k gives label l2 when true label y
  Lcond = aperm(a1, perm = c(1,3,4,2)) * aperm(a2, perm = c(1,4,3,2))
  # Lcond[k,l1,l2,y] = probability independent worker pair k give labels (l1,l2) when true label y
  if(which == 'Lcond') return(Lcond)
  joint = Lcond * with(tL, aperm(array(md$m, dim = c(C,C,C,npair)), perm = c(4,2,3,1)))
  # joint[k,l1,l2,y] = Lcond[k,l1,l2,y] * Probability(True label is y)
  result = list(Lcond = Lcond, joint = joint)
  if(which == 'joint') return(result)
  marginL = apply(joint, MARGIN = c(1,2,3), FUN = sum)
  # marginL[k,l1,l2] = probability independent worker pair k give labels (l1,l2) 
  result = c(result, list(marginL = marginL))
  if(which == 'marginL') return(result)
  condL = joint / array(marginL, dim = dim(joint))
  # condL[k,l1,l2,y] = probability(True label is y | independent worker pair k give labels (l1,l2) )
  condL[is.na(condL)] = 0
  result = c(result, list(condL = condL))
  if(which == 'condL') return(result)
}

EM.DS = function(init, tL, EM_par = alg_par()){
  tstart = Sys.time()
  md = init
  probs = ind_pair_prob(md, tL, which = 'condL')
  md$logLik = logLik.DS(md,tL,marginL = probs$marginL)
  for(nloop in 1:EM_par$maxit){
    pre_md = md
    condL_eq = aperm(apply(probs$condL, MARGIN = c(1,4), FUN = diag), perm = c(2,1,3))
    condL_eq[pre_md$H == 0,,] = 0
    
    if(!pre_md$m.fix){
      Lcond_eq = aperm(apply(probs$Lcond, MARGIN = c(1,4), FUN = diag), perm = c(2,1,3))
      Lcond_eq[pre_md$H == 0,,] = 0
      # update m
      p1 = apply(Lcond_eq, MARGIN = c(1,3), FUN = sum) # p1[k,c] = p(Li=Lj|Z=0,Y=c) for pair (i,j) = k with H_k > 0
      # p1[k,c] = p(Li=Lj,y=c|theta)
      p1 = (p1 * (1 - pre_md$H) + pre_md$H) * matrix(pre_md$m, nrow = tL$npair, ncol = tL$C, byrow = TRUE)
      # p1[k,c] = p(y=c|Li=Lj, theta) for pair (i,j) = k with H_k > 0
      p1 = p1 / rowSums(p1)
      m = apply(probs$condL * array(tL$count, dim = dim(probs$condL)), MARGIN = 4, FUN = sum, na.rm = TRUE) - apply(condL_eq * array(tL$count_eq, dim = dim(condL_eq)), MARGIN = 3, FUN = sum, na.rm = TRUE) + colSums(p1 * tL$total_eq, na.rm = TRUE)
      md$m = m/sum(m)
      
      md$m[md$m < 1e-4] = 1e-4
      md$m[md$m > 1 - 1e-4] = 1 - 1e-4
      md$m = md$m / sum(md$m)
    }
    
    if(!all(pre_md$H.fix)){
      margin_eq = t(apply(probs$marginL, MARGIN = 1, FUN = diag))
      H = tL$total_eq / tL$total * pre_md$H / (rowSums(margin_eq) * (1 - pre_md$H) + pre_md$H)
      H[is.na(H)] = 0
      H[H > 1 - 1e-4] = 1 - 1e-4
      H[md$H.fix] = pre_md$H[md$H.fix]
      md$H = H
    }
    
    if(!all(pre_md$a.fix)){
      joint_eq = aperm(apply(probs$joint, MARGIN = c(1,4), FUN = diag), perm = c(2,1,3))
      joint_eq[pre_md$H == 0,,] = 0
      # only update workers not fixed
      # equal[k,l,c] = p(Li=Lj=l,y=c,h=0|theta) for pair k=(i,j) and H_k > 0
      equal = joint_eq * (1 - pre_md$H)
      # equal[k,l,c] = p(y=c,h=0,Li=Lj=l|Li=Lj,theta)
      equal = equal / (apply(equal, MARGIN = 1, FUN = sum) + pre_md$H)
      p3 = equal * tL$total_eq 
      p3[is.na(p3)] = 0
      p3 = p3 - condL_eq * array(tL$count_eq, dim = dim(condL_eq))
      p2 = probs$condL * array(tL$count, dim = dim(probs$condL))
      d1 = apply(p2, MARGIN = c(1,2,4), FUN = sum, na.rm = T) + p3
      d2 = apply(p2, MARGIN = c(1,3,4), FUN = sum, na.rm = T) + p3
      a = array(0, dim = c(tL$nworker, tL$C, tL$C))
      # sum up according to worker1
      tmp = sum_up(d1, tL$worker1, FALSE)
      a[tmp$idx,,] = a[tmp$idx,,] + tmp$result
      # sum up according to worker2
      tmp = sum_up(d2, tL$worker2, TRUE)
      a[tmp$idx,,] = a[tmp$idx,,] + tmp$result
      a = aperm(a, c(1,3,2))
      a = update_a(a, class(md)[1])
      a[a < 1e-4] = 1e-4
      a[a > 1 - 1e-4] = 1 - 1e-4
      a = update_a(a,class(md)[1])
      a[md$a.fix,,] = md$a[md$a.fix,,]
      md$a = a
    }
    
    probs = ind_pair_prob(md, tL, which = 'condL')
    md$logLik = logLik.DS(md,tL,marginL = probs$marginL)
    
    # stopping criteria
    stopping = with(md, logLik - pre_md$logLik <= EM_par$tol * abs(logLik))
    if(stopping) break
  }
  recorder = c('niter' = nloop, 'nrun' = 1, 'total_time' = difftime(Sys.time(), tstart, units = 'secs'))
  return(list(md = md, recorder = recorder))
}

Penalized_CD.DS = function(init, tL, lambda, penalty = penalty_fun('lasso'), weight = NULL, EM_par = alg_par(), CD_par = alg_par()){
  # penalty_gradient must be non-decreasing regarding H at interval (0,1)
  tstart = Sys.time()
  recorder = c(0,0,0)
  if(is.null(weight)) weight = rep(1,length(init$H))
  md = init
  probs = ind_pair_prob(md, tL, which = 'joint')
  joint_eq = aperm(apply(probs$joint, MARGIN = c(1,4), FUN = diag), perm = c(2,1,3))
  md$logLik = logLik.DS(md,tL,marginL = probs$marginL)
  md$obj = md$logLik - sum(tL$total * weight * penalty$obj(md$H, lambda))
  
  for(nloop in 1:CD_par$maxit){
    pre_md = md
    
    # Update H
    # gradient of the penalized univariate functions at H=0
    eq_prob = apply(joint_eq, MARGIN = 1, FUN = sum)
    gf0 = DS_uniH_gradient(eq_prob, tL, !md$H.fix,0) - tL$total[!md$H.fix] * weight[!md$H.fix] * penalty$gradient(0, lambda)
    idx = (1:length(md$H))[!md$H.fix]
    md$H[idx[gf0 <= 0]] = 0
    for(k in idx[gf0 > 0]){
      fn = function(x) DS_uniH_gradient(eq_prob,tL,k,x) - tL$total[k] * weight[k] * penalty$gradient(x, lambda)
      if(fn(1 - 1e-4) > 0) md$H[k] = 1 - 1e-4
      else{
        result = uniroot(f = fn, lower = 0, upper = 1 - 1e-4)
        md$H[k] = result$root
      }
    }
    
    tmp_md = md
    tmp_md$H.fix[] = TRUE
    r = EM.DS(tmp_md,tL,EM_par)
    recorder = recorder + r$recorder
    
    r$md$H.fix = md$H.fix
    md = r$md
    probs = ind_pair_prob(md, tL, which = 'joint')
    joint_eq = aperm(apply(probs$joint, MARGIN = c(1,4), FUN = diag), perm = c(2,1,3))
    md$obj = md$logLik - sum(tL$total * weight * penalty$obj(md$H, lambda))
    
    # stopping criteria
    stopping = with(md, obj - pre_md$obj <= CD_par$tol * abs(obj))
    if(stopping) break
  }
  recorder = rbind(recorder, c(nloop, 1, difftime(Sys.time(), tstart, units = 'secs')))
  rownames(recorder) = c('EM', 'CD')
  md$lambda = lambda
  return(list(md = md, recorder = recorder))
}

DS_uniH_gradient = function(eq_prob, tL, selector, value){
  B = eq_prob[selector] / (1 - eq_prob[selector])
  A = tL$total_eq[selector] / (B + value)
  A[is.na(A)] = 0
  gradient = - (tL$total[selector] - tL$total_eq[selector]) / (1 - value) + A
  return(gradient)
}