get_LicondY = function(md,L,...){
  UseMethod('get_LicondY',md)
}

get_LicondY.DS = function(md,L){
  ntask = nrow(L)
  nworker = ncol(L)
  C = length(md$m)
  idx = cbind(rep(1:nworker,each = ntask), as.vector(L))
  idx = cbind(idx[rep(1:nrow(idx), C),], rep(1:C, each = nrow(idx)))
  idx = idx[,c(1,3,2)]
  Licond = array(md$a[idx], dim = c(ntask, nworker, C))
  # Licond[t,i,c] = p(l_(i,t) | Yt = c)
  return(Licond)
}

get_LicondY.GLAD = function(md,L){
  Licond = get_LicondY_GLAD(md$beta, md$alpha, L, length(md$m))
  # Licond[t,i,c] = p(l_(i,t) | Yt = c)
  return(Licond)
}

get_LicondY_GLAD = function(beta, alpha, L, C){
  correct_prob = plogis(outer(beta, alpha))
  incorrect_prob = (1 - correct_prob)/(C - 1)
  indicatorL = aperm(array(1:C, dim = c(C, dim(L))),perm = c(2,3,1))
  Licond = extend_dim(correct_prob,C) * (extend_dim(L,C) == indicatorL) + extend_dim(incorrect_prob, C) * (extend_dim(L,C) != indicatorL)
  return(Licond)
}

add_par = function(params, nworker, ntask, ...){
  UseMethod("add_par",params)
}

add_par.DS = function(params, nworker, ntask = NULL, a = 0.7, a.fix = FALSE){
  # For Dawid-Skene model
  C = length(params$m)
  if(length(a) == 1) params$a = get_a(rep(a,nworker), C)
  else if(is.vector(a) || dim(a) == 2) params$a = get_a(a)
  else if(dim(a) == 3) params$a = a
  
  if(length(a.fix) == 1) params$a.fix = rep(a.fix, nworker)
  else params$a.fix = a.fix
  stopifnot(length(params$a.fix) == nworker)
  return(params)
}

add_par.GLAD = function(params, nworker, ntask, alpha = 0.8473, beta = 1, alpha.fix = FALSE, beta.fix = FALSE){
  # For GLAD model
  C = length(params$m)
  params$alpha = alpha * rep(1, nworker)
  params$alpha.fix = alpha.fix | rep(FALSE,nworker)
  params$beta = beta * rep(1, ntask)
  params$beta.fix = beta.fix | rep(FALSE,ntask)
  return(params)
}

get_a = function(a.diag, C=2){
  if(is.vector(a.diag)) a.diag = matrix(a.diag, nrow = length(a.diag), ncol = C)
  a = array(0, dim = c(nrow(a.diag), C, C))
  for(i in 1:nrow(a.diag)) {
    a[i,,] = matrix((1 - a.diag[i,])/(C - 1), nrow = C, ncol = C)
    diag(a[i,,]) = a.diag[i,]
  }
  return(a)
}

alg_par = function(tol = 1e-6, maxit = 2000){
  return(list(tol = tol, maxit = maxit))
}

update_a = function(a, className = 'general'){
  a.total = apply(a, MARGIN = c(1,2), FUN = sum)
  if(className == 'general') return(a / array(a.total, dim = dim(a)))
  a = t(apply(a, MARGIN = 1, FUN = diag))
  if(className == 'dependent') return(get_a(a / a.total, ncol(a.total)))
  if(className == 'homogeneous') return(get_a(rowSums(a) / rowSums(a.total), ncol(a.total)))
  if(className == 'uniform') return(get_a(rep(sum(a) / sum(a.total), nrow(a.total)), ncol(a.total)))
}

mv = function(L, C, gold = NULL){
  # Majority voting
  dummy = matrix(1:C, nrow = nrow(L), ncol = C, byrow = TRUE)
  L = cbind(L, dummy)
  pred = t(apply(L, MARGIN = 1, FUN = table))
  pred = pred - 1
  pred = apply(pred, MARGIN = 1, FUN = which.max)
  if(is.null(gold)) return(pred)
  return(sum(pred[!is.na(gold)] == gold[!is.na(gold)]) / sum(!is.na(gold)))
}

extend_dim = function(A, add_dim){
  B = array(A, dim = c(dim(A), add_dim))
  return(B)
}

EM = function(init, ...){
  UseMethod('EM', object = init)
}

infer = function(md, ...){
  UseMethod('infer')
}

Qfunc = function(x0, md, ...){
  UseMethod('Qfunc',md)
}

Penalized_CD = function(init, ...){
  UseMethod('Penalized_CD')
}

special_DS = function(){
  source("DS_collusion_func.R")
}

unspecial_DS = function(){
  rm(logLik.DS,ind_pair_prob,EM.DS,Penalized_CD.DS,DS_uniH_gradient, pos = 1)
}

clean_label = function(L, gt = NULL, min.worker = 3, min.task = 3){
  indicator1 = rowSums(!is.na(L)) >= min.worker
  indicator2 = colSums(!is.na(L)) >= min.task
  while(any(indicator1 == FALSE) || any(indicator2 == FALSE)){
    L = L[indicator1,]
    gt = gt[indicator1]
    L = L[,indicator2]
    indicator1 = rowSums(!is.na(L)) >= min.worker
    indicator2 = colSums(!is.na(L)) >= min.task
  }
  return(list(L = L, gt = gt))
}