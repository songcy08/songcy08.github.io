library(doParallel)

pairwise_labels = function(L,C){
  # Transform labels into pairwise format
  # Input:
  #   L - a matrix of worker labels
  #   C - number of alternatives
  # Output:
  #   labels in pairwise format
  ntask = nrow(L)
  nworker = ncol(L)
  
  pL = array(0, dim = c(nworker, nworker, C, C))
  for(i in 1:ntask){
    idx = !is.na(L[i,])
    D = data.frame(worker = which(idx), label = L[i,idx])
    if(nrow(D) >= 2){
      pair = t(combn(1:nrow(D), m = 2))
      D1 = D[pair[,1],]
      D2 = D[pair[,2],]
      pL[cbind(D1$worker,D2$worker,D1$label,D2$label)] = pL[cbind(D1$worker,D2$worker,D1$label,D2$label)] + 1
    }
  }
  spL = apply(pL, MARGIN = c(1,2), FUN = sum)
  count = apply(pL, MARGIN = c(3,4), FUN = function(x) x[spL >= 1])
  worker1 = row(spL)[spL >= 1]
  worker2 = col(spL)[spL >= 1]
  count_eq = t(apply(count, MARGIN = 1, FUN = diag))
  count_uneq = t(apply(count, MARGIN = 1, FUN = function(x) x[row(x)!=col(x)]))
  tL = list(nworker = nworker, ntask = ntask, C = C, npair = length(worker1), worker1 = worker1, worker2 = worker2, L = L, count = count, count_eq = count_eq, count_uneq = count_uneq, total = apply(count, MARGIN = 1, FUN = sum), total_eq = rowSums(count_eq))
  return(tL)
}

collusion_model = function(nworker, npair, ntask = NULL, C = 2, H=0, H.fix = FALSE, m = NULL, m.fix = FALSE, ..., className = NULL){
  # This function construct the model, currently there are the following options
  # className = 'GLAD'
  # className = c('general','DS') or c('dependent','DS') or c('homogeneous','DS') or c('uniform','DS')
  # Input:
  #   H - colluding probabilities
  #   H.fix - do we fix H?
  if(length(H) == 1) params = list(H = rep(H, npair))
  else params = list(H = H)
  stopifnot(length(params$H) == npair)
  
  if(length(H.fix) == 1) params$H.fix = rep(H.fix, npair)
  else params$H.fix = H.fix
  stopifnot(length(params$H.fix) == npair)
  
  if(is.null(m)) params$m = rep(1/C, C)
  else params$m = m
  stopifnot(length(params$m) == C)
  
  params$m.fix = m.fix
  
  class(params) = c(className,'collusion')
  params = add_par(params, nworker, ntask, ...)
  return(params)
}

get_ind_joint = function(md, tL){
  Licond = get_LicondY(md, tL$L)
  ind_joint = Licond[,tL$worker1,] * Licond[,tL$worker2,] * aperm(array(md$m, dim = c(tL$C, tL$ntask, tL$npair)), perm = c(2,3,1))
  return(ind_joint)
}

get_eq_joint = function(md, tL){
  # ntask - nworker - y - l
  Li_eq = lapply(1:tL$C, FUN = function(x) get_LicondY(md, matrix(x,nrow = tL$ntask, ncol = tL$nworker)))
  Li_eq = array(unlist(Li_eq), dim = c(tL$ntask, tL$nworker, tL$C, tL$C))
  eq_joint = Li_eq[,tL$worker1,,] * Li_eq[,tL$worker2,,] * aperm(array(md$m, dim = c(tL$C, tL$ntask, tL$npair, tL$C)), perm = c(2,3,1,4))
  return(eq_joint)
}

logLik.collusion = function(md, tL, ind_joint = NULL, eq_joint = NULL){
  # Obtain the pairwise loglikelihood
  if(is.null(ind_joint)) ind_joint = get_ind_joint(md, tL)
  uneq = t(apply(ind_joint, MARGIN = c(1,2), FUN = sum)) * (1 - md$H)
  
  if(is.null(eq_joint))  eq_joint = get_eq_joint(md, tL)
  eq = t(apply(eq_joint, MARGIN = c(1,2), FUN = sum)) * (1-md$H) + md$H
  
  likelihood = with(tL,sum((L[,worker1] != L[,worker2]) * t(log(uneq)) + (L[,worker1] == L[,tL$worker2]) * t(log(eq)), na.rm = TRUE))
  
  return(likelihood)
}

BIC.collusion = function(md, tL){
  bic = -2 * md$logLik + sum(log(tL$total) * (md$H != 0))
  return(bic)
}

AIC.collusion = function(md, tL=NULL, k=2){
  aic = -2 * md$logLik + k * sum(md$H != 0)
  return(aic)
}

EM.collusion = function(init, tL, EM_par = alg_par(),...){
  # Pairwise EM algorithm for collusion detection
  tstart = Sys.time()
  md = init
  ind_joint = get_ind_joint(md, tL)
  eq_joint = get_eq_joint(md, tL)
  md$logLik = logLik.collusion(md, tL, ind_joint, eq_joint)
  blanket = with(tL, (L[,worker1] != L[,worker2]) | matrix(md$H == 0, nrow = ntask, ncol = npair, byrow = TRUE)) # indicator of independence
  for(nloop in 1:EM_par$maxit){
    pre_md = md
    tmpH = with(tL, matrix(md$H, nrow = ntask, ncol = npair, byrow = TRUE))
    eq_margin = tmpH + (1 - tmpH) * apply(eq_joint, MARGIN = c(1,2), FUN = sum)
    Y_cond_Z0L = ind_joint / array(apply(ind_joint, MARGIN = c(1,2), FUN = sum), dim = dim(ind_joint))
    LZ0Y_cond_eq = eq_joint * (1 - array(tmpH,dim = dim(eq_joint))) / array(eq_margin, dim = dim(eq_joint))
    
    if(!pre_md$m.fix){
      part2 = apply(LZ0Y_cond_eq, MARGIN = c(1,2,3), FUN = sum) + aperm(array(outer(pre_md$H, pre_md$m), dim = c(tL$npair,tL$C, tL$ntask)), perm = c(3,1,2)) / extend_dim(eq_margin, tL$C)
      md$m = apply(Y_cond_Z0L  * array(blanket,dim = dim(Y_cond_Z0L)) + part2 * array(!blanket, dim = dim(part2)), MARGIN = 3, FUN = sum, na.rm = TRUE)
      md$m = md$m / sum(md$m)
      md$m[md$m < 1e-4] = 1e-4
      md$m[md$m > 1 - 1e-4] = 1 - 1e-4
      md$m = md$m / sum(md$m)
    }
    
    if(!all(pre_md$H.fix)){
      H = rowSums(pre_md$H / t(eq_margin) * t(tL$L[,tL$worker1] == tL$L[,tL$worker2]), na.rm = TRUE) / tL$total
      H[H > 1 - 1e-4] = 1 - 1e-4
      H[md$H.fix] = pre_md$H[md$H.fix]
      md$H = H
    }
    
    md = collusion_update_params(md, Y_cond_Z0L, LZ0Y_cond_eq, blanket, tL,...)
    ind_joint = get_ind_joint(md, tL)
    eq_joint = get_eq_joint(md, tL)
    md$logLik = logLik.collusion(md, tL, ind_joint, eq_joint)
    
    stopping = with(md, logLik - pre_md$logLik <= EM_par$tol * abs(logLik))
    if(stopping) break
  }
  recorder = c('niter' = nloop, 'nrun' = 1, 'total_time' = difftime(Sys.time(), tstart, units = 'secs'))
  return(list(md = md, recorder = recorder))
}

collusion_update_params = function(md, ...){
  UseMethod('collusion_update_params')
}

collusion_update_params.DS = function(md, Y_cond_Z0L, LZ0Y_cond_eq, blanket, tL){
  if(!all(md$a.fix)){
    p1 = (with(tL, extend_dim(L[,worker1], c(C,C)) == aperm(array(1:C, dim = c(C,C,npair,ntask)), perm = c(4,3,2,1))) & extend_dim(blanket, c(tL$C,tL$C))) * extend_dim(Y_cond_Z0L, tL$C) + extend_dim(!blanket, c(tL$C,tL$C)) * LZ0Y_cond_eq
    p1 = apply(p1, MARGIN = c(2,3,4), FUN = sum)
    p2 = (with(tL, extend_dim(L[,worker2], c(C,C)) == aperm(array(1:C, dim = c(C,C,npair,ntask)), perm = c(4,3,2,1))) & extend_dim(blanket, c(tL$C,tL$C))) * extend_dim(Y_cond_Z0L, tL$C) + extend_dim(!blanket, c(tL$C, tL$C)) * LZ0Y_cond_eq
    p2 = apply(p2, MARGIN = c(2,3,4), FUN = sum)
    a = array(0, dim = c(tL$nworker, tL$C, tL$C))
    # sum up according to worker1
    tmp = sum_up(p1, tL$worker1, FALSE)
    a[tmp$idx,,] = a[tmp$idx,,] + tmp$result
    # sum up according to worker2
    tmp = sum_up(p2, tL$worker2, TRUE)
    a[tmp$idx,,] = a[tmp$idx,,] + tmp$result
    a = update_a(a, class(md)[1])
    a[a < 1e-4] = 1e-4
    a[a > 1 - 1e-4] = 1 - 1e-4
    a = update_a(a,class(md)[1])
    a[md$a.fix,,] = md$a[md$a.fix,,]
    md$a = a
  }
  return(md)
}

sum_up = function(M, worker.idx, assorted = FALSE){
  if(!assorted) {
    idx = order(worker.idx)
    M = M[idx,,]
    worker.idx = worker.idx[idx]
  }
  idx = which(!duplicated(worker.idx)) - 1
  idx = c(idx[-1], length(worker.idx))
  sm = apply(M, MARGIN = c(2,3), FUN = cumsum)
  sm = sm[idx,,]
  sm[2:dim(sm)[1],,] = apply(sm, MARGIN = c(2,3), FUN = diff)
  idx = worker.idx[idx]
  return(list(result = sm, idx = idx))
}

collusion_update_params.GLAD = function(md, Y_cond_Z0L, LZ0Y_cond_eq, blanket, tL, GLAD_par = alg_par(1e-2, 2)){
  for(nloop in 1:GLAD_par$maxit){
    pre_md = md
    # update alpha
    #alpha = md$alpha
    alpha = foreach(widx = which(!md$alpha.fix), .export = lsf.str(.GlobalEnv)) %dopar% {
    #for(widx in which(!md$alpha.fix)){
      idx = (tL$worker1 == widx ) | (tL$worker2 == widx)
      result = optimize(collusion_Qfunc_GLAD_alpha, interval = c(-6,6), beta = md$beta, L = tL$L[,widx], C = tL$C, Y_cond_Z0L = Y_cond_Z0L[,idx,,drop = FALSE], LZ0Y_cond_eq = LZ0Y_cond_eq[,idx,,,drop = FALSE], blanket = blanket[,idx,drop = FALSE], maximum = TRUE)$maximum
      #alpha[widx] = result
      return(result)
    }
    #md$alpha = alpha
    md$alpha[!md$alpha.fix] = unlist(alpha)
    
    # update beta
    #beta = md$beta
    beta = foreach(tidx = which(!md$beta.fix), .export = lsf.str(.GlobalEnv)) %dopar% {
    #for(tidx in which(!md$beta.fix)){
      # beta[tidx]
      result = optimize(collusion_Qfunc_GLAD_beta, interval = c(0,6), alpha = md$alpha, L = tL$L[tidx,,drop = FALSE], C = tL$C, Y_cond_Z0L = Y_cond_Z0L[tidx,,], LZ0Y_cond_eq = LZ0Y_cond_eq[tidx,,,], blanket = blanket[tidx,], worker1 = tL$worker1, worker2 = tL$worker2, maximum = TRUE)$maximum
      #beta[tidx] = result
      return(result)
    }
    md$beta[!md$beta.fix] = unlist(beta)
    #md$beta = beta
    
    if(sum(abs(md$alpha - pre_md$alpha)) + sum(abs(md$beta - pre_md$beta)) < GLAD_par$tol * (sum(abs(pre_md$alpha)) + sum(pre_md$beta))) break
  }
  return(md)
}

collusion_Qfunc_GLAD_alpha = function(alpha, beta, L, C, Y_cond_Z0L, LZ0Y_cond_eq, blanket){
  ntask = length(beta)
  n = ncol(blanket)
  Licond = get_LicondY_GLAD(beta, rep(alpha,n), matrix(L, nrow = ntask, ncol = n), C)
  part1 = apply(log(Licond) * Y_cond_Z0L, MARGIN = c(1,2), FUN = sum)
  Licond = lapply(1:C, FUN = function(x) get_LicondY_GLAD(beta, rep(alpha, n), matrix(x, nrow = ntask, ncol = n), C))
  Licond = array(unlist(Licond), dim = c(ntask, n, C, C))
  part2 = apply(log(Licond) * LZ0Y_cond_eq, MARGIN = c(1,2), FUN = sum)
  Q = sum(part1 * blanket + part2 * (!blanket), na.rm = T)
  return(Q)
}

collusion_Qfunc_GLAD_beta = function(beta, alpha, L, C, Y_cond_Z0L, LZ0Y_cond_eq, blanket, worker1, worker2){
  nworker = length(alpha)
  Licond = get_LicondY_GLAD(beta, alpha, L, C)
  Lcond = Licond[,worker1,] * Licond[,worker2,]
  part1 = apply(log(Lcond) * Y_cond_Z0L, MARGIN = 1, FUN = sum)
  
  Li_eq = lapply(1:C, FUN = function(x) get_LicondY_GLAD(beta, alpha, matrix(x, nrow = 1, ncol = nworker), C))
  Li_eq = array(unlist(Li_eq), dim = c(1,nworker,C,C))
  Li_eq = drop(Li_eq)
  eq = Li_eq[worker1,,] * Li_eq[worker2,,]
  part2 = apply(log(eq) * LZ0Y_cond_eq, MARGIN = 1, FUN = sum)
  Q = sum(part1 * blanket + part2 * (!blanket), na.rm = T)
  return(Q)
}

penalty_fun = function(className = 'lasso'){
  # Penalty function
  if(className == 'lasso'){
    obj = function(x,lambda) return(x*lambda)
    gradient = function(x, lambda) return(lambda)
    gradient_inv = function(x, rhs) return(rhs)
  }
  func = list(obj = obj, gradient = gradient, gradient_inv = gradient_inv)
  class(func) = 'lasso'
  return(func)
}

uniH_gradient = function(eq_prob, blanket, selector, value){
  B = eq_prob[,selector, drop = F]
  B = B / (1 - B)
  blanket = blanket[,selector, drop = F]
  gradient = colSums(- blanket / (1 - value) + (!blanket) / (B + value), na.rm = T)
  return(gradient)
}

Penalized_CD.collusion = function(init, tL, lambda, penalty = penalty_fun('lasso'), weight = NULL, EM_par = alg_par(), CD_par = alg_par()){
# penalty_gradient must be non-decreasing regarding H at interval (0,1)
  # The coordinate descent algorithm for collusion model
  tstart = Sys.time()
  recorder = c(0,0,0)
  if(is.null(weight)) weight = rep(1,length(init$H))
  md = init
  eq_joint = get_eq_joint(md, tL)
  blanket = with(tL, (L[,worker1] != L[,worker2])) # indicator of independence
  md$logLik = logLik.collusion(md,tL,eq_joint = eq_joint)
  md$obj = md$logLik - sum(tL$total * weight * penalty$obj(md$H, lambda))
  
  for(nloop in 1:CD_par$maxit){
    pre_md = md
    
    # Update H
    # gradient of the penalized univariate functions at H=0
    eq_prob = apply(eq_joint, MARGIN = c(1,2), FUN = sum)
    gf0 = uniH_gradient(eq_prob, blanket, !md$H.fix,0) - tL$total[!md$H.fix] * weight[!md$H.fix] * penalty$gradient(0, lambda)
    idx = (1:length(md$H))[!md$H.fix]
    md$H[idx[gf0 <= 0]] = 0
    results = foreach(k = idx[gf0 > 0], .export = lsf.str(.GlobalEnv)) %dopar% {
      fn = function(x) uniH_gradient(eq_prob,blanket,k,x) - tL$total[k] * weight[k] * penalty$gradient(x, lambda)
      if(fn(1 - 1e-4) > 0) return(1 - 1e-4)
      else{
        result = uniroot(f = fn, lower = 0, upper = 1 - 1e-4)
        return(result$root)
      }
    }
    md$H[idx[gf0 > 0]] = unlist(results)
    
    tmp_md = md
    tmp_md$H.fix[] = TRUE
    r = EM.collusion(tmp_md,tL,EM_par)
    recorder = recorder + r$recorder
    
    r$md$H.fix = md$H.fix
    md = r$md
    eq_joint = get_eq_joint(md, tL)
    md$obj = md$logLik - sum(tL$total * weight * penalty$obj(md$H, lambda))
    
    # stopping criteria
    stopping = with(md, obj - pre_md$obj <= CD_par$tol * abs(obj))
    if(stopping) break
  }
  recorder = rbind(recorder, c(nloop, 1, difftime(Sys.time(), tstart, units = 'secs')))
  rownames(recorder) = c('EM', 'CD')
  md$lambda = lambda
  return(list(md = md, recorder = recorder))
}

lambda_threshold = function(md, tL, blanket, penalty = penalty_fun('lasso'), weight = NULL){
  if(is.null(weight)) weight = rep(1, length(md$H))
  idx = !md$H.fix
  eq_joint = get_eq_joint(md, tL)
  eq_prob = apply(eq_joint,MARGIN = c(1,2), FUN = sum)
  rhs = uniH_gradient(eq_prob, blanket, idx, 0) /(tL$total[idx] * weight[idx])
  lambda_cands = penalty$gradient_inv(0, rhs)
  return(lambda_cands)
}

insert_ref = function(ref, md){
  record = c(md$lambda, sum(md$H == 0), unlist(md[colnames(ref)[3:ncol(ref)]]))
  if(nrow(ref) == 0 || md$lambda > ref[nrow(ref),'lambda']) ref = rbind(ref, record)
  else if(md$lambda < ref[1,'lambda']) ref = rbind(record, ref)
  else if(all(ref[,'lambda'] != md$lambda)){
    position = sum(ref[,'lambda'] < md$lambda)
    ref = rbind(ref[1:position,], record, ref[(position+1):nrow(ref),])
  }
  return(ref)
}

next_lambda = function(ref, nsearch = 5, tol = 1e-6){
  candidate = NULL
  r1 = aggregate(IC ~ nzeros, data = ref, FUN = min)
  for(i in order(r1[,'IC'])[1:min(c(nsearch,nrow(r1)))]){
    if(i == 1 && r1$IC[i] < r1$IC[i+1] && r1$nzeros[i+1] - r1$nzeros[i] >= 2){
      lambda1 = max(ref[ref[,'nzeros'] == r1$nzeros[i], 'lambda'])
      lambda2 = min(ref[ref[,'nzeros'] == r1$nzeros[i+1],'lambda'])
      if(lambda2 - lambda1 > tol) candidate = c(candidate, mean(c(lambda1, lambda2)))
    } else if (i == nrow(r1) && r1$IC[i] < r1$IC[i-1] && r1$nzeros[i] - r1$nzeros[i-1] >= 2){
      lambda1 = min(ref[ref[,'nzeros'] == r1$nzeros[i], 'lambda'])
      lambda2 = max(ref[ref[,'nzeros'] == r1$nzeros[i-1], 'lambda'])
      if(lambda1 - lambda2 > tol) candidate = c(candidate, mean(c(lambda1, lambda2)))
    } else if(i > 1 && i < nrow(r1) && r1$IC[i] < min(r1$IC[c(i-1,i+1)])) {
      lambda1 = min(ref[ref[,'nzeros'] == r1$nzeros[i], 'lambda'])
      lambda2 = max(ref[ref[,'nzeros'] == r1$nzeros[i-1], 'lambda'])
      if(lambda1 - lambda2 > tol && r1$nzeros[i] - r1$nzeros[i-1] >= 2) candidate = c(candidate, mean(c(lambda1, lambda2)))
      lambda1 = max(ref[ref[,'nzeros'] == r1$nzeros[i], 'lambda'])
      lambda2 = min(ref[ref[,'nzeros'] == r1$nzeros[i+1], 'lambda'])
      if(lambda2 - lambda1 > tol && r1$nzeros[i+1] - r1$nzeros[i] >= 2) candidate = c(candidate, mean(c(lambda1, lambda2)))
    }
  }
  candidate = unique(candidate)
  candidate = setdiff(candidate, ref[,'lambda'])
  return(candidate)
}

collusion = function(init, tL, IC = list(bic = BIC), penalty = penalty_fun('lasso'), weight = NULL, nsearch = 5, tol = 1e-6, EM_par = alg_par(), CD_par = alg_par()){
  # The collusion model estimation
  print('starting')
  tstart = Sys.time()
  recorder = matrix(0, nrow = 2, ncol = 3)
  ref = matrix(0,nrow = 0, ncol = 2 + length(IC), dimnames = list(rownames = NULL, colnames = c(c('lambda','nzeros'),names(IC))))
  if(is.null(weight)) weight = rep(1,length(init$H))
  blanket = with(tL, (L[,worker1] != L[,worker2])) # indicator of independence
  sol_short = function(x) Penalized_CD(init, tL, x, penalty, weight, EM_par, CD_par)
  md = vector('list',length = length(IC))
  names(md) = names(IC)
  
  # let lambda = 0 and try
  print('solving lambda = 0')
  result = sol_short(0)
  print(difftime(Sys.time(), tstart, units = 'secs'))
  for(i in 1:length(IC)) result$md[[names(IC)[i]]] = IC[[i]](result$md, tL)
  ref = insert_ref(ref, result$md)
  recorder = recorder + result$recorder
  for(i in 1:length(IC)) md[[i]] = result$md
  
  # find out the maximum lambda
  print('solving sparse EM')
  init1 = init
  init1$H[!init1$H.fix] = 0
  init1$H.fix[] = TRUE
  sparse = EM(init1, tL, EM_par)$md
  sparse$H.fix = init$H.fix
  lambda = lambda_threshold(sparse, tL, blanket, penalty, weight)
  lambda = max(lambda)
  # lambda = 50
  repeat{
    print('verifying largest lambda')
    result = sol_short(lambda)
    recorder = recorder + result$recorder
    if(all(result$md$H[!result$md$H.fix] == 0)) break
    else lambda = lambda * 1.1
  }
  for(i in 1:length(IC)){
    result$md[[names(IC)[i]]] = IC[[i]](result$md, tL)
    if(md[[i]][[names(IC)[i]]] > result$md[[names(IC)[i]]]) md[[i]] = result$md
  }
  ref = insert_ref(ref, result$md)
  
  # initial sequence of lambda
  print('generating sequence')
  lambdas = 1 / 2^seq(from = 10, to = 1, by = -1) * lambda
  # grid search
  while(!is.null(lambdas) && length(lambdas) >= 1)
  {
    results = foreach(lambda = lambdas, .export = lsf.str(.GlobalEnv)) %dopar% {
      print(lambda)
      result = sol_short(lambda)
      for(i in 1:length(IC)) result$md[[names(IC)[i]]] = IC[[i]](result$md, tL)
      return(result)
    }
    for(i in 1:length(results)){
      ref = insert_ref(ref, results[[i]]$md)
      recorder = recorder + results[[i]]$recorder
      for(j in 1:length(IC)){
        if(md[[j]][[names(IC)[j]]] > results[[i]]$md[[names(IC)[j]]]) md[[j]] = results[[i]]$md
      }
    }
    lambdas = NULL
    for(i in 1:length(IC)){
      ref1 = ref[,c(c('lambda','nzeros'),names(IC)[i])]
      colnames(ref1)[3] = 'IC'
      lambdas = c(lambdas, next_lambda(ref1, nsearch, tol))
    }
    lambdas = unique(lambdas)
  }

  recorder = rbind(recorder, c(nrow(ref), 1, difftime(Sys.time(), tstart, units = 'secs')))
  rownames(recorder)[3] = 'path'
  ref = as.data.frame(ref)
  rownames(ref) = 1:nrow(ref)
  return(list(md = md, recorder = recorder, ref = ref))
}

infer.collusion = function(md, tL, gold = NULL, prob = TRUE){
  # Infer true labels based on the collusion model
  Licond = get_LicondY(md, tL$L)
  ind_joint = Licond[,tL$worker1,] * Licond[,tL$worker2,]
  tmpH = aperm(array(md$H, dim = c(tL$npair, tL$ntask, tL$C)), perm = c(2,1,3))
  result = log(ind_joint * (1 - tmpH) + 1/tL$C * extend_dim(tL$L[,tL$worker1] == tL$L[,tL$worker2], tL$C) * tmpH)
  result = apply(result, MARGIN = c(1,3), FUN = sum, na.rm = TRUE) + matrix(log(md$m), nrow = tL$ntask, ncol = tL$C, byrow = TRUE)
  result = exp(result - apply(result, MARGIN = 1, FUN = max))
  result = result / rowSums(result)
  if(prob && is.null(gold)) return(result)
  result = apply(result, MARGIN = 1, FUN = which.max)
  if(is.null(gold)) return(result)
  return(sum(result[!is.na(gold)] == gold[!is.na(gold)]) / sum(!is.na(gold)))
}
