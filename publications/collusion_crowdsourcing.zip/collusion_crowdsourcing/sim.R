library(doParallel)
source("common_func.R")
source("independent_func.R")
source("collusion_func.R")
source("sim_func.R")
special_DS()

# simulation configuration ------------------------------------------------
ncollude = 3; b = 0.7; h = 0.5;
niter = 100;
config = sim_config(nworker = 10, ncollude = ncollude, h = h, m = c(0.6, 0.4), a = 0.7, b = b)
ntasks = c(25, 50, 100, 200, 500, 1000)
cl = makeCluster(5)
registerDoParallel(cl)

print(paste('ncollude is',ncollude,'; b is',b,'; h is', h))

# generate data 
ys = Ls = array(vector(mode = 'list'), dim = c(length(ntasks), niter))
for(p in 1:length(ntasks))
  for(iter in 1:niter){
    tmp = sim_L(config,ntask = ntasks[p])
    ys[[p,iter]] = tmp$y
    Ls[[p,iter]] = tmp$L
  }

# conduct analysis
Methods = c('independent', 'collusion+AIC', 'collusion+BIC')
Bases = c('uniform DS', 'homogeneous DS')
params = array(vector(mode = 'list'), dim = c(length(ntasks), length(Bases), length(Methods), niter), dimnames = list(ntask = ntasks, base = Bases, method = Methods, iter = 1:niter))
recorder = array(vector(mode = 'list'), dim = c(length(ntasks), length(Bases), niter), dimnames = list(ntask = ntasks, base = Bases, iter = 1:niter))
acc = array(0, dim = c(length(ntasks), length(Bases), length(Methods) + 1, niter), dimnames = list(ntask = ntasks, base = Bases, method = c('mv',Methods), iter = 1:niter))
Hhat = array(0, dim = c(config$nworker * (config$nworker - 1) / 2, length(ntasks), length(Bases), niter), dimnames = list(NULL, ntask = ntasks, base = Bases, iter = 1:niter))

for(n in 1:length(ntasks)){
  print(paste('ntasks is',ntasks[n]))
  tLs = foreach(iter = 1:niter, .packages = 'slam') %dopar% {
    tL = pairwise_labels(Ls[[n,iter]], length(config$m))
    return(tL)
  }

  for(base in Bases){
    print(paste('base model is', base))
    
    # independent method
    print('independent benchmark method')
    init = independent_model(config$nworker, ntask = ntasks[n], C = length(config$m), className = strsplit(base,' ')[[1]])
    params[n,base,'independent',] = mapply(FUN = EM.independent, L = Ls[n,], MoreArgs = list(init = init), SIMPLIFY = FALSE)
    acc[n,base,'independent', ] = mapply(infer, md = params[n,base,'independent',], L = Ls[n,], gold = ys[n, ])
    
    # Collusion method
    print('Calculating unpenalized estimator')
    init = collusion_model(config$nworker, config$nworker * (config$nworker - 1) / 2, ntask = ntasks[n], C = length(config$m), H = 0.5, className = strsplit(base,' ')[[1]])
    unpenalize = foreach(iter = 1:niter, .export = ls(.GlobalEnv)) %do% {
      result = EM(init, tL = tLs[[iter]])
      return(result$md)
    }

    # collusion + AIC
    print('collusion')
    results = vector('list',niter)
    #results = foreach(iter = 1:niter, .export = ls(.GlobalEnv)) %do% {
    for(iter in 1:niter){
      print(iter)
      weight = 1/unpenalize[[iter]]$H
      weight[is.infinite(weight)] = max(c(weight[!is.infinite(weight)], 1e10)) + 1
      result = collusion(init, tL, IC = list(aic=AIC,bic=BIC), weight = weight)
      results[[iter]] = result
      #save(result, file = paste(iter,'.RData',sep=''))
      #return(result)
    }
    params[n,base,'collusion+AIC',] = mapply(FUN = function(x) x$md$aic, results, SIMPLIFY = F)
    params[n,base,'collusion+BIC',] = mapply(FUN = function(x) x$md$bic, results, SIMPLIFY = F)
    recorder[n,base,] = mapply(FUN = function(x) x$recorder, results, SIMPLIFY = F)
    acc[n,base,'collusion+AIC',] = mapply(infer, md = params[n,base,'collusion+AIC',], tL = tLs, gold = ys[n, ])
    acc[n,base,'collusion+BIC',] = mapply(FUN = infer, md = params[n,base,'collusion+BIC',], tL = tLs, gold = ys[n, ])
    Hhat[,n,base,] = sapply(params[n,base,'collusion+BIC',], FUN = function(x) x$H)
  }
  
  ## for vote, calculate the metrics
  acc[n,,'mv', ] = rep(mapply(mv, L = Ls[n, ], gold = ys[n, ], MoreArgs = list(C = length(config$m))), each = length(Bases))
}
stopCluster(cl)