sim_config = function(nworker, ncollude, h, m, a, b){
  # Simulation configuration
  # Input:
  #   nworker - number of workers
  #   ncollude - number of colluders
  #   h - probability of collusion
  #   m - marginal probability of true label
  #   a - accuracy of independent worker
  #   b - accuracy of colluding worker
  # Output: configuration
  config = list(nworker = nworker, ncollude = ncollude, h = h, m = m)
  config$a.extend = get_a(c(rep(a,nworker),b), C = length(m))
  return(config)
}

sim_L = function(config, ntask){
  # Generate simulated worker labels
  # Input:
  #   ntask - number of tasks to consider
  # Output:
  #   A matrix of generated tasks with true labels and worker labels
  C = length(config$m)
  nworker = config$nworker
  y = sample(1:C, size = ntask, replace = T, prob = config$m)
  R = matrix(runif(ntask * (nworker + 1)), nrow = ntask, ncol = nworker + 1)
  L = matrix(0, nrow = ntask, ncol = nworker + 1)
  for(i in 1:ncol(L)){
    # for worker i
    a.piece = config$a.extend[i,y,]
    a.piece = t(apply(a.piece, MARGIN = 1, FUN = cumsum))
    L[,i] = rowSums(R[,i] > a.piece) + 1
  }
  collude = runif(ntask) <= config$h
  L[collude, 1:config$ncollude] = L[collude, nworker + 1]
  L = L[,1:nworker]
  return(list(y = y, L = L))
}