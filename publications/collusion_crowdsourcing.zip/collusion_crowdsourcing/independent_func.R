library(doParallel)

independent_model = function(nworker, ntask = NULL, C = 2, m = NULL, m.fix = FALSE, ..., className = NULL){
  # This function construct the independent worker model, currently there are the following options
  # className = 'GLAD'
  # className = c('general','DS') or c('dependent','DS') or c('homogeneous','DS') or c('uniform','DS')
  # Input:
  #   nworker - number of workers
  #   ntask - number of tasks
  #   C - number of alternatives
  #   m - marginal probability of true label
  #   m.fix - do we update m?
  # Output:
  #   The independent worker model
  params = list()
  if(is.null(m)) params$m = rep(1/C, C)
  else params$m = m
  stopifnot(length(params$m) == C)
  
  params$m.fix = m.fix
  
  class(params) = c(className,'independent')
  params = add_par(params, nworker, ntask, ...)
  return(params)
}

ind_all_prob = function(md, L){
  # This function calculate the probabilities
  ntask = nrow(L)
  nworker = ncol(L)
  C = length(md$m)
  Licond = get_LicondY(md,L)
  # Licond[t,i,c] = p(l_(i,t) | Yt = c)
  Lcond = apply(Licond, MARGIN = c(1,3), FUN = prod, na.rm = TRUE)
  # Lcond[t,c] = p(Lt | Yt = c)
  joint =  Lcond * matrix(md$m, nrow = ntask, ncol = C, byrow = TRUE)
  # joint[t,c] = p(Lt, Yt = c)
  marginal = rowSums(joint)
  # condL[t,c] = p(Yt = c|Lt)
  condL = joint / marginal
  return(list(marginal = marginal, condL = condL))
}

logLik.independent = function(md, L, marginal = NULL){
  # This function calculate the log likelihood
  if(is.null(marginal)) marginal = ind_all_prob(md, L)$marginal
  result = sum(log(marginal), na.rm = TRUE)
  return(result)
}

EM.independent = function(init, L, EM_par = alg_par(), ...){
  # The EM algorithm for independent workers
  ntask = nrow(L)
  nworker = ncol(L)
  C = length(init$m)
  
  md = init
  probs = ind_all_prob(md, L)
  
  md$logLik = logLik.independent(md, L, probs$marginal)
  
  for(nloop in 1:EM_par$maxit){
    pre_md = md
    if(!pre_md$m.fix){
      md$m = colSums(probs$condL, na.rm = TRUE)
      md$m = with(md, m / sum(m))
    }
    
    md = ind_update_params(md, L, probs$condL, ...)
    
    probs = ind_all_prob(md, L)
    md$logLik = logLik.independent(md, L, probs$marginal)
    
    stopping = with(md,logLik - pre_md$logLik <= EM_par$tol * abs(logLik))
    if(stopping) break
  }
  return(md)
}

ind_update_params = function(md, ...){
  UseMethod('ind_update_params')
}

ind_update_params.DS = function(md, L, condL){
  C = length(md$m)
  ntask = nrow(L)
  nworker = ncol(L)
  A = aperm(array(condL, dim = c(ntask, C, C, nworker)), perm = c(1,4,2,3)) * (aperm(array(1:C, dim = c(C, C, ntask,nworker)), perm = c(3,4,2,1)) == array(L, dim = c(ntask, nworker, C, C)))
  a = apply(A, MARGIN = c(2,3,4), FUN = sum, na.rm = T)
  a = update_a(a, class(md)[1])
  a[a < 1e-4] = 1e-4
  a[a > 1 - 1e-4] = 1 - 1e-4
  a = update_a(a,class(md)[1])
  a[md$a.fix,,] = md$a[md$a.fix,,]
  md$a = a
  return(md)
}

ind_update_params.GLAD = function(md, L, condL, GLAD_par = alg_par(1e-4, 5)){
  for(nloop in 1:GLAD_par$maxit){
    pre_md = md
    # update alpha
    alpha = foreach(widx = which(!md$alpha.fix), .export = lsf.str(.GlobalEnv)) %dopar% {
      result = optimize(Ind_Qfunc_GLAD, interval = c(-6,6), other = md$beta, L = L[,widx, drop = FALSE], condL = condL, C = length(md$m), change.seq = TRUE, maximum = TRUE)$maximum
      return(result)
    }
    md$alpha[!md$alpha.fix] = unlist(alpha)
    # update beta
    beta = foreach(tidx = which(!md$beta.fix), .export = lsf.str(.GlobalEnv)) %dopar% {
      result = optimize(Ind_Qfunc_GLAD, interval = c(0,6), other = md$alpha, L = L[tidx,,drop = FALSE], condL = condL[tidx,], C = length(md$m), maximum = TRUE)$maximum
      return(result)
    }
    md$beta[!md$beta.fix] = unlist(beta)
    if(sum(abs(md$alpha - pre_md$alpha)) + sum(abs(md$beta - pre_md$beta)) < GLAD_par$tol * (sum(abs(pre_md$alpha)) + sum(pre_md$beta))) break
  }
  return(md)
}
  
Ind_Qfunc_GLAD = function(x, other, L, condL, C, change.seq = FALSE){
  if(change.seq) prob = get_LicondY_GLAD(other, x, L, C)
  else prob = get_LicondY_GLAD(x,other,L,C)
  prob = drop(prob)
  if(is.vector(condL)) prob = t(prob)
  Q = sum(condL * log(prob), na.rm = TRUE)
  return(Q)
}

infer.independent = function(md, L, gold = NULL, prob = TRUE){
  # Inferring the true label based on independent worker model
  result  = ind_all_prob(md, L)$condL
  if(prob && is.null(gold)) return(result)
  result = apply(result, MARGIN = 1, FUN = which.max)
  if(is.null(gold)) return(result)
  return(sum(result[!is.na(gold)] == gold[!is.na(gold)]) / sum(!is.na(gold)))
}