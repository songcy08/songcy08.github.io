%% Dataset 1
clear; clc;
disp('Processing data');
trRaw=dlmread('Engine_sim_data/train_FD001.txt');
trSet = mat2set(trRaw,true);
tsRaw=dlmread('Engine_sim_data/test_FD001.txt');
tsSet = mat2set(tsRaw,true);
tsRUL=dlmread('Engine_sim_data/RUL_FD001.txt');
colnames={'altitudes','Mach','sea-level(temperatures)',...
    'T2','T24','T30','T50','P2','P15','P30','Nf','Nc','epr','Ps30','phi','NRf','NRc',...
    'BPR','farB','htBleed','Nf_dmd','PCNfR_dmd','W31','W32'};

% select sensors
load('dataset1.mat');
trSet.L = trSet.L(:,sensor_idx);
tsSet.L = tsSet.L(:,sensor_idx);
[trSet,tsSet] = Standardize(trSet,tsSet,trend(sensor_idx));

%% transform the format
trSet = unsynchronize(trSet);
tsSet = unsynchronize(tsSet);

%% predict
config_base = struct('nMC',25,'HalfnTs',80,'DeltaTs', 0.5, 'gamma',1);
config_logistic = Overwrite(config_base,struct('classifier','logistic'));
config_svm = Overwrite(config_base,struct('classifier','svm',...
    'kernel','polynomial','PolynomialOrder',2));
config_nn = Overwrite(config_base,struct('classifier','nn','LayerSize',10));

n_sensor = max(trSet.sigIdx);
params.p = 3*ones(1,n_sensor);
params.psi = { @(t) ones(length(t),1), @(t) t, @(t) t.^2 };
params.psi = repmat(params.psi,1,n_sensor);
params.scale = 1;
par = mmixef(trSet,params); % estimate prior parameters

posterior = postprob(trSet,par,params,config_base.nMC);
posterior2 = postprob(tsSet,par,params,config_base.nMC);

[~,info] = estimate_MC(trSet.Life,posterior.samples,posterior.sampIdx...
                ,params,config_logistic,true);

out_logistic = fitModel(info.D,info.y,config_logistic);
[result_logistic,Ts,~] = failure_probs(out_logistic,posterior2.samples,posterior2.sampIdx,tsSet.Life,params,config_logistic);
rul_logistic = RUL(result_logistic,Ts,true);

addpath('libsvm-master/windows'); % I use libsvm for nonlinear SVM
out_svm = fitModel(info.D, info.y, config_svm);
[result_svm,Ts,svmmono] = failure_probs(out_svm,posterior2.samples,posterior2.sampIdx,tsSet.Life,params,config_svm);
rul_svm = RUL(result_svm,Ts,true);

out_nn = fitModel(info.D,info.y,config_nn);
[result_nn,~,nnmono] = failure_probs(out_nn,posterior2.samples,posterior2.sampIdx,tsSet.Life,params,config_nn);
rul_nn = RUL(result_nn,Ts,true);

ruls_11sensors = [rul_logistic,rul_nn];
Errors_11sensors = abs(repmat(tsRUL,1,size(ruls_11sensors,2)) - ruls_11sensors)./...
    repmat(tsRUL + tsSet.Life,1,size(ruls_11sensors,2));

RULlevels=[max(tsRUL), 100, 80, 60, 40, 20];
Err=zeros(length(RULlevels),size(Errors_11sensors,2));
for i=1:length(RULlevels)
    idx = tsRUL<=RULlevels(i);
    Err(i,:)=mean(Errors_11sensors(idx,:),1);
end