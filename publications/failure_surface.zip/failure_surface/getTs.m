function ts = getTs(life,config)
% This function returns the time points for sampling signal path
% Input:
%   life    --  life of unit
%   config    --  configuration
% Output:
%   ts    --  time points for sampling signal path

N = min(floor(life/config.DeltaTs),config.HalfnTs);
b1 = life - config.DeltaTs * N;
e1 = life + config.DeltaTs * (N-1);
ts = (b1:config.DeltaTs:e1)';