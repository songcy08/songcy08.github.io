function [probs,Ts,monotonicity] = failure_probs(out,samples,unitIdx,currentLife,params,config,tentative_max)
% Calculate the failure probability distribution
% Input:
%   out    --  classifier
%   samples    --  sampled gammas
%   unitIdx    --  unit index
%   currentLife    --  empty for training units; current life for testing
%                      units
%   params    --  general path model parameters
%   config    --  configuration
%   tentative_max    --  maximum value of possible failure time
% Output:
%   probs    --  failure probability
%   Ts    --  corresponding time points
%   monotonicity    --  whether the faiilure probability is monotonic wrt
%                       time

if(nargin < 7)
    tentative_max = 1500;
end

n_unit = max(unitIdx);
probs = cell(n_unit,1);
Ts = cell(n_unit,1);
monotonicity = false(n_unit,1);
for i = 1:n_unit
    if ~isempty(currentLife)
        ts = (currentLife(i):0.1:tentative_max)';
    else
        ts = (50:0.1:tentative_max);
    end
    Ts{i} = ts;
    [D,~] = getD(samples(:,unitIdx == i), ts, params, true);
    prob = predictModel(out,D,config);
    prob = reshape(prob,length(ts),sum(unitIdx == i));
    prob = mean(prob,2);
    if ~isempty(currentLife) % in-field units
        if prob(1) == 1
            prob(1) = 1 - 1e-10;
        end
        prob = (prob - prob(1))/(1-prob(1));
    end
    probs{i} = prob;
    monotonicity(i) = all(diff(probs{i}) >= 0) && probs{i}(end) >= 0.5;
end