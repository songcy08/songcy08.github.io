function [L,life] = set2mat(Set)

% This function does the opposite of mat2set

if isfield(Set,'sigIdx')
    L = [Set.unitIdx,Set.sigIdx,Set.Ts,Set.L];
else
    L = [Set.unitIdx,Set.Ts,Set.L];
end
life = Set.Life;