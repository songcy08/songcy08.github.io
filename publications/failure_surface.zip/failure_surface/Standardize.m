function [trNew, tsNew] = Standardize(trSet, tsSet, trend)

% This function standardizes the signals
% Input:
%   trSet    --  signals of training set in structure format
%   tsSet    --  signals of testing set in structure format
%   trend    --  increasing (1) or decreasing (-1) trend of each signal
% Output:
%   trNew    --  standardized training data
%   tsNew    --  standardized testing data

trNew = trSet; tsNew = tsSet;
% standardize training data
[trNew.L, mu, sigma]=zscore(trNew.L.*repmat(trend, size(trNew.L,1), 1));
for i=1:max(trNew.unitIdx)
    idx = trNew.unitIdx == i;
    tmp=trNew.L(idx,:);
    tmp=min(tmp,[],1)-exp(tmp(1,:));
    trNew.L(idx,:)=trNew.L(idx,:)-repmat(tmp,sum(idx),1);
end
trNew.L = log(trNew.L);
trNew.L = trNew.L.*repmat(trend,size(trNew.L,1),1); % trend changes back

% standardize testing data
tsNew.L=(tsNew.L.*repmat(trend, size(tsNew.L,1),1)...
    -repmat(mu,size(tsNew.L,1),1))./repmat(sigma,size(tsNew.L,1),1);
for i=1:max(tsNew.unitIdx)
    idx = tsNew.unitIdx == i;
    tmp = tsNew.L(idx,:);
    tmp = min(tmp,[],1)-exp(tmp(1,:));
    tsNew.L(idx,:)=tsNew.L(idx,:)-repmat(tmp,sum(idx),1);
end
tsNew.L = log(tsNew.L);
tsNew.L = tsNew.L.*repmat(trend, size(tsNew.L,1) ,1);