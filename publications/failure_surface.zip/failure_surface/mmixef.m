function par = mmixef(Set,params)

% This function estimates prior parameters for multiple signals
% Input:
%   Set    --  signals
%   params    --  general path model parameters
% Output:
%   par    --  prior distribution parameters

n_sensor = max(Set.sigIdx);
pidx = repelem(1:n_sensor,params.p);
par.mu = []; par.Sigma = []; par.omega = []; par.sigma2 = []; par.Gamma = [];
for j = 1:n_sensor
    idx = Set.sigIdx == j;
    par1 = mixef(Set.L(idx),Set.unitIdx(idx),Set.Ts(idx),params.psi(pidx==j));
    par.mu = [par.mu;par1.mu];
    par.Sigma = blkdiag(par.Sigma,par1.Sigma);
    par.omega = blkdiag(par.omega,par1.omega);
    par.sigma2 = [par.sigma2,par1.sigma2];
    par.Gamma = [par.Gamma, par1.Gamma];
end