function mgamma = block_par(gamma,p)
% this function transforms a vector gamma to a matrix mgamma
% Input:
%   gamma    --  a vector, concatenating parameters for each signal
%   p    --  a vector, number of dimensions of parameter for each signal
% Output:
%   mgamma    --  a block diagonal matrix. Each block is a parameter for
%   one signal

pidx = repelem(1:length(p),p);
mgamma = [];
for i = 1:max(pidx)
    mgamma = blkdiag(mgamma,gamma(pidx == i));
end