function beta = fitLinearSVM(X,y,init,config)
% Fit a linear SVM model
% Input:
%   X    --  predictor
%   y    --  response
%   init    --  initial guess
%   config    -- configuration
% Output:
%   beta    -- coeffficient

options = optimoptions(@fminunc,'Algorithm','quasi-newton','FiniteDifferenceType',...
    'central','Display','off','MaxFunctionEvaluations',5000,'MaxIterations',4000);
beta = fminunc(@(b) svmloss(b,X,y) + svmpenalty(b,config),init,options);

function loss = svmloss(beta,X,y)
fx = [ones(size(X,1),1),X] * beta;
y(y == 0) = -1;
loss = max([1 - y.* fx,zeros(length(y),1)],[],2);
loss = sum(loss);

function penalty = svmpenalty(beta,config)
penalty = config.svm_penalty * sum(beta(2:end).^2);