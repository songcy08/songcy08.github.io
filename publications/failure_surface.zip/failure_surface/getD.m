function [D,tsnew] = getD(realizations,ts,params,scaleit)
% This function calculates the value of signal path at specified time
% points
% Input:
%   realizations    --  samples of gamma
%   ts    --  time points to calculate signal path
%   params    --  general path model settings
%   scaleit    --  wheter to standardize the result
% Output:
%   D    --  value of signal path
%   tsnew    --  corresponding time points

n_sensor = length(params.p);
nPerReal = length(ts);
nReal = size(realizations,2);
D = zeros(nReal * nPerReal,n_sensor);
Psi = design_matrix(ts,params.psi);
for k = 1:nReal
    D((k-1)*nPerReal+1 : k*nPerReal,:) = Psi * block_par(realizations(:,k),params.p);
end
tsnew = repmat(ts,nReal,1);
if scaleit
    D = D./params.scale;
end