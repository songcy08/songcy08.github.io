function Psi = design_matrix(ts,psi,sigIdx,p)

% design matrix for all signals
% Input:
%   ts    --  a column vector ts = [ts_1;...;ts_m] where ts_m is the
%   time series for unit m, and ts_i = [ts_(i,1);...;ts_(i,s)] where
%   ts_(i,j) is the time series for unit i, sensor j.
%   psi    --  a row vector psi = [psi_1, ..., psi_s] where psi_j is for
%   signal j
%   sigIdx    --  column vector same length as ts. which signal the
%   recording belongs to?
%   p    --  a row vector specifying dimension of parameter for each signal
%
% Output:
%   Psi    --  a matrix. Psi = [Psi_1;...;Psi_m] where 
%   Psi_i = diag(Psi_(i,1),...,Psi_(i,s)) where Psi_(i,j) is the design matrix 
%   for unit i signal j.

if nargin < 4
    p = length(psi);
end
if nargin < 3
    sigIdx = ones(length(ts),1);
end
n_sensor = length(p);
assert(length(psi) == sum(p));
pidx = repelem(1:length(p),p); % each dimension belongs to which signal
Psi = zeros(length(ts),length(psi));
for i = 1:n_sensor
    Psi(sigIdx == i, pidx == i) = dm(ts(sigIdx == i),psi(pidx == i));
end

function Psi = dm(ts,psi)
% design matrix for a single sensor
Psi = ones(length(ts),length(psi));
for j = 1:length(psi)
    Psi(:,j) = psi{j}(ts);
end