function rul = RUL(ftprobs,Ts,returnRUL)
% calculate remaining useful life
% Input:
%   ftprobs    --  failure probability
%   Ts    --  corresponding time points
%   returnRUL    --  whether return RUL or failure time
% Output:
%   rul    --  predicted rul or failure time

n_unit = length(ftprobs);
rul = zeros(n_unit,1);
for i = 1:n_unit
    ts = Ts{i};
    if max(ftprobs{i}) >= 0.5
        rul(i) = ts(find(ftprobs{i} >= 0.5,1));
    else
        rul(i) = ts(end);
        disp('Median not met');
    end
    if returnRUL
        rul(i) = rul(i) - ts(1);
    end
end