function newSet = unsynchronize(Set)

% This function transforms data format for signals from synchronized signals into unsynchronized signals
% Synchronized signal format means each column represents a signal
% Unsynchronized format means one column for sensor index, and one column for measurement
% Input:
%   Set    --  signals in synchronized structure format
% Output:
%   newSet    --  signals in unsynchronized structure format

n_sensor = size(Set.L,2);
newSet.unitIdx = repmat(Set.unitIdx,n_sensor,1);
newSet.Ts = repmat(Set.Ts,n_sensor,1);
newSet.sigIdx = repelem((1:n_sensor)',size(Set.L,1));
newSet.L = reshape(Set.L,numel(Set.L),1);
newSet.Life = Set.Life;
[Signals,~] = set2mat(newSet);
Signals = sortrows(Signals);
newSet = mat2set(Signals,false);
newSet.Life = Set.Life;