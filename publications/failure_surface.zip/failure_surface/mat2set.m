function [Set,unitmap] = mat2set(Mat,synchronized)

% this function converts sensor signals from matrix format into set format
% Input:
%   Mat    --  signals as matrix, first column is unit index, second column is time
%   synchronized    --  whether signals are synchronized
% Output:
%   Set    --  signals in structure format
%   unitmap    --  collection of units

unitmap = unique(Mat(:,1));
[~,Set.unitIdx] = ismember(Mat(:,1),unitmap); 
Mat(:,1) = Set.unitIdx;
Mat = sortrows(Mat);
if ~synchronized
    assert(size(Mat,2) == 4);
    Set.sigIdx = Mat(:,2);
    Mat = Mat(:,[1,3:end]);
end
Set.Ts = Mat(:,2);
Set.Life = Set.Ts(diff([Set.unitIdx;max(Set.unitIdx)+1])>0);
Set.L = Mat(:,3:end);