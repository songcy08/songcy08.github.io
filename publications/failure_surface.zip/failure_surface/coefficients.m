function coef = coefficients(model,config)
% this function extract estimated coefficients for trained classifier model

switch config.classifier
    case 'logistic'
        if isa(model,'double')
            coef = model;
        else
            coef = model.Coefficients.Estimate;
        end
    case 'svm'
        if isa(model,'double')
            coef = model;
        else
            w = model.SVs' * model.sv_coef;
            b = -model.rho;
            if model.Label(1) < model.Label(2)
                w = -w;
                b = -b;
            end
            coef = [b;w];
        end
end