function prob = postprob(Set,par,params,nMC)

% This function calculate posterior probability and generate random samples for general path models
% Input:
%   Set    --  dataset
%   par    --  prior parameters
%   params    --  the general path model parameters for each signal
%   nMC    --  number of realizations for each unit
% Output:
%   prob    --  a structure containing random samples, posterior functions,
%   and posterior mean

n_unit = max(Set.unitIdx);
prob.samples = zeros(sum(params.p),n_unit * nMC);
prob.sampIdx = zeros(1,n_unit*nMC);
prob.fun = cell(n_unit,1);
prob.mui = zeros(sum(params.p),n_unit);
prob.Sigmai = cell(n_unit,1);
for i = 1:n_unit
    idx = Set.unitIdx == i;
    Psi = design_matrix(Set.Ts(idx),params.psi,Set.sigIdx(idx),params.p);
    invSigma2 = diag(1./par.sigma2(Set.sigIdx(idx)));
    Sigmai = pinv(Psi'* invSigma2 *Psi + par.omega);
    Sigmai = (Sigmai + Sigmai')/2;
    mui = Sigmai * (Psi'* invSigma2 *Set.L(idx) + par.omega * par.mu);
    prob.samples(:,(i-1)*nMC+1:i*nMC) = mvnrnd(mui',Sigmai,nMC)';
    prob.sampIdx((i-1)*nMC+1:i*nMC) = i;
    prob.fun{i} = @(x)mvnpdf(x,mui,Sigmai);
    prob.mui(:,i) = mui;
    prob.Sigmai{i} = Sigmai;
end