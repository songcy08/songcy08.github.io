%% Sensor selection for dataset 1
clear; clc;
disp('Processing data');
trRaw=dlmread('Engine_sim_data/train_FD001.txt');
trSet = mat2set(trRaw,true);
tsRaw=dlmread('Engine_sim_data/test_FD001.txt');
tsSet = mat2set(tsRaw,true);
tsRUL=dlmread('Engine_sim_data/RUL_FD001.txt');
colnames={'altitudes','Mach','sea-level(temperatures)',...
    'T2','T24','T30','T50','P2','P15','P30','Nf','Nc','epr','Ps30','phi','NRf','NRc',...
    'BPR','farB','htBleed','Nf_dmd','PCNfR_dmd','W31','W32'};

% select sensors
load('dataset1.mat');
full_idx = find(trend ~= 0);
trSet.L = trSet.L(:,full_idx);
tsSet.L = tsSet.L(:,full_idx);
[trSet,tsSet] = Standardize(trSet,tsSet,trend(full_idx));

%% transform the format
trSet = unsynchronize(trSet);
tsSet = unsynchronize(tsSet);

%% sensor selection
config_base = struct('nMC',25,'HalfnTs',80,'DeltaTs', 0.5, 'gamma',1);
config_logistic = Overwrite(config_base,struct('classifier','logistic'));

n_sensor = max(trSet.sigIdx);
params.p = 3*ones(1,n_sensor);
params.psi = { @(t) ones(length(t),1), @(t) t, @(t) t.^2 };
params.psi = repmat(params.psi,1,n_sensor);
params.scale = 1;
par = mmixef(trSet,params);

posterior = postprob(trSet,par,params,config_base.nMC);
[out_logistic,info] = estimate_MC(trSet.Life,posterior.samples,posterior.sampIdx...
                ,params,config_logistic,false);
addpath ./glmnet_matlab/ % I use glmnet package to implement adaptive lasso
penalty = coefficients(out_logistic,config_logistic);
lasso_out = glmnet(info.D, info.y,'binomial',glmnetSet(struct(...
    'penalty_factor',1./abs(penalty(2:end)).^config_base.gamma,...
    'thresh',1e-6,'lambda_min',1e-6,'nlambda',200,'maxit',1e6,...
    'weights',info.weight)));
trial = unique((lasso_out.beta ~= 0)','rows');
trial(1:end-1,:) = trial(2:end,:);
trial(end,:) = true;
mErrs = inf(size(trial,1),1);
sErrs = mErrs;
for i = 1:size(trial,1)
    sidx = trial(i,:);
    config_select = Overwrite(config_logistic,struct('select_variable',sidx));
    [mErrs(i),sErrs(i),~] = CV(partition,posterior,trSet.Life,config_select,params);
end
[~,i] = min(mErrs);
sidx = trial(i,:);

%% 2. Do it again with selected sensors
trSet = mat2set(trRaw,true);
tsSet = mat2set(tsRaw,true);
selected_idx = full_idx(sidx);
trSet.L = trSet.L(:,selected_idx);
tsSet.L = tsSet.L(:,selected_idx);
[trSet,tsSet] = Standardize(trSet,tsSet,trend(selected_idx));

%% transform the format
trSet = unsynchronize(trSet);
tsSet = unsynchronize(tsSet);

%% do it
config_base = struct('nMC',25,'HalfnTs',80,'DeltaTs', 0.5, 'gamma',1);
config_logistic = Overwrite(config_base,struct('classifier','logistic'));
config_svm = Overwrite(config_base,struct('classifier','svm',...
    'kernel','polynomial','PolynomialOrder',2));
config_nn = Overwrite(config_base,struct('classifier','nn','LayerSize',10));

n_sensor = max(trSet.sigIdx);
params.p = 3*ones(1,n_sensor);
params.psi = { @(t) ones(length(t),1), @(t) t, @(t) t.^2 };
params.psi = repmat(params.psi,1,n_sensor);
params.scale = 1;
par = mmixef(trSet,params);

posterior = postprob(trSet,par,params,config_base.nMC);
posterior2 = postprob(tsSet,par,params,config_base.nMC);

[~,info] = estimate_MC(trSet.Life,posterior.samples,posterior.sampIdx...
                ,params,config_logistic,true);

out_logistic = fitModel(info.D,info.y,config_logistic);
[result_logistic,Ts,~] = failure_probs(out_logistic,posterior2.samples,posterior2.sampIdx,tsSet.Life,params,config_logistic);
rul_logistic = RUL(result_logistic,Ts,true);

addpath('libsvm-3.22/windows');
out_svm = fitModel(info.D, info.y, config_svm);
[result_svm,Ts,svmmono] = failure_probs(out_svm,posterior2.samples,posterior2.sampIdx,tsSet.Life,params,config_svm);
rul_svm = RUL(result_svm,Ts,true);

out_nn = fitModel(info.D,info.y,config_nn);
[result_nn,~,nnmono] = failure_probs(out_nn,posterior2.samples,posterior2.sampIdx,tsSet.Life,params,config_nn);
rul_nn = RUL(result_nn,Ts,true);

ruls_select = [rul_logistic,rul_svm,rul_nn];
Errors_select = abs(repmat(tsRUL,1,size(ruls_select,2)) - ruls_select)./...
    repmat(tsRUL + tsSet.Life,1,size(ruls_select,2));

RULlevels=[max(tsRUL), 100, 80, 60, 40, 20];
Err=zeros(length(RULlevels),size(Errors_select,2));
for i=1:length(RULlevels)
    idx = tsRUL<=RULlevels(i);
    Err(i)=mean(Errors_select(idx,:),1);
end