function z = Overwrite(basevalue,addon)

% This function add new fields to a structure
% Input:
%   basevalue    --  a structure
%   addon    --  new fields to be added
% Output:
%   z    --  structure with new fields added

z = basevalue;
if isstruct(addon)
    names = fieldnames(addon);
    for i = 1:length(names)
        z.(names{i}) = addon.(names{i});
    end
end