function [beta,info] = estimate_Laplace(posterior,Life,params,config)
% this function implement laplace approximation
% Input:
%   init    --  initial estimates of parameters, each column for one unit
%   Set    --  dataset
%   params    --  parameter structure
%   config    --  configuration structure
%   probfun    --  cell of posterior probaility function for each unit
% Output:
%   out    --  trained classifier
%   info    --  other information

[out,info] = estimate_MC(Life,posterior.mui,1:size(posterior.mui,2),params,...
   config,false);
out = coefficients(out,config);
options = optimoptions(@fminunc,'Algorithm','quasi-newton','FiniteDifferenceType',...
    'central','Display','iter-detailed','MaxFunctionEvaluations',5000,'MaxIterations',4000);
[beta,fval,exitflag,output] = fminunc(@(x) Laplace_obj(posterior.mui,x,Life...
    ,posterior.fun,params,config),out,options);
info.obj = fval;
info.niter = output.iterations;
info.converge = exitflag;

function obj = Laplace_obj(init,beta,Life,fun,params,config)
% Calculate the objective function using Laplacian approximation
% Input:
%   init  --  initial guess
%   beta  --  parameter value
%   Life  --  training unit failure time
%   fun  --  loss function of classifier
%   params  --  general path model parameter
%   config  --  other configurations
% Output:
%   obj  --  objective function evaluated at beta

n_unit = length(Life);
options = optimoptions(@fminunc,'Algorithm','quasi-newton','FiniteDifferenceType',...
    'central','Display','off','MaxFunctionEvaluations',5000,'MaxIterations',4000);
obj_part = zeros(n_unit,1);
len = zeros(n_unit,1);
parfor i = 1:n_unit
    ts = getTs(Life(i),config);
    y = [zeros(length(ts)/2,1);ones(length(ts)/2,1)];
    Fi = @(x) -log(LossFun(x,y,beta,ts,params,config)) - log(fun{i}(x));
    [gamma,~,~,~,~,H] = fminunc(Fi,init(:,i),options);
    obj_part(i) = sqrt(abs(1/det(H))) * fun{i}(gamma) * LossFun(gamma,y,beta,ts,params,config)/length(ts);
    len(i) = length(ts);
end
obj = mean(obj_part) * sum(len) + Penalty(beta,config);

function Loss = LossFun(gamma,y,out,ts,params,config)
% value of loss function given gamma, y, and trained classifier out
[D,~] = getD(gamma,ts,params,true);
switch config.classifier
    case 'logistic' % deviance as loss
        yhat = predictModel(out,D,config);
        Loss = sum(-2*log((y == 1).*yhat + (y == 0).* (1-yhat)));
        if isinf(Loss) && Loss < 0
            Loss = - 1e99;
        elseif isinf(Loss) && Loss > 0
            Loss = 1e99;
        end
    case 'svm'
        fx = [ones(size(D,1),1),D] * out;
        y(y == 0) = -1;
        Loss = max([1 - y.* fx,zeros(length(y),1)],[],2);
        Loss = sum(Loss);
end

function penalty = Penalty(beta,config)
penalty = 0;
if strcmp(config.classifier,'svm')
    penalty = config.svm_penalty * sum(beta(2:end).^2);
end