function out = fitModel(X,y,config)
% Fit a classifier
% Input:
%   X    --  predictors
%   y    --  response
% Output:
%   out    --  classifier

if ~isfield(config,'weight')
    config.weight = ones(length(y),1);
else
    config.weight = config.weight/sum(config.weight) * length(y);
end

if isfield(config,'select_variable')
    X = X(:,config.select_variable);
end

switch config.classifier
    case 'probit'
        out = fitglm(X,y,'linear','Distribution','binomial','Link','probit','Weights',config.weight);
    case 'logistic'
        out = fitglm(X,y,'linear','Distribution','binomial','Link','logit','Weights',config.weight);
    case 'svm'
        if strcmp(config.kernel, 'linear')
            out = fitLinearSVM(X,y,zeros(size(X,2)+1,1),config);
        elseif strcmp(config.kernel, 'polynomial')
            out = svmtrain(y,X,'-t 1 -d 2 -b 1');
        end
    case 'knn'
        out = fitcknn(X,y,'Distance','euclidean','NumNeighbors',config.NumNeighbors,'Standardize',true);
    case 'rf'
        out = TreeBagger(config.NumTrees,X,y,'Method','classification','MaxNumSplits',config.MaxNumSplits);
    case 'ensemble'
        out = fitcensemble(X,y,'NumLearningCycles',config.NumLearningCycles,'Learners',templateTree('MaxNumSplits',config.MaxNumSplits));
    case 'nn'
        net = patternnet(config.LayerSize);
        [out,~] = train(net,X',[1-y,y]');
end