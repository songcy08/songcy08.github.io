function [mErr,sErr,rul] = CV(partition,posterior,Life,config,params)
% This function conducts cross validation
% Input:
%   partition  --  partition of training set
%   posterior  --  output of postprobs
%   Life  --  failure time
%   config  --  configuration
%   params  --  general path model parameters
% Output:
%   mErr  --  averaged error
%   sErr  --  standard deviation of the cv error
%   rul  --  predicted cv rul

nunit = max(posterior.sampIdx);
rul = cell(1,partition.NumTestSets);
parfor i = 1:partition.NumTestSets
    rul{i} = zeros(nunit,1);
    trIdx = training(partition,i);
    tsIdx = test(partition,i);
    [idx1,idx2] = ismember(posterior.sampIdx,find(trIdx));
    [out,info] = estimate_MC(Life(trIdx),posterior.samples(:,idx1),idx2(idx1)...
            ,params,config,false);
    [idx1,idx2] = ismember(posterior.sampIdx,find(tsIdx));
    [result,Ts,~] = failure_probs(out,posterior.samples(:,idx1),idx2(idx1),[],params,config);
    rul{i}(tsIdx) = RUL(result,Ts,false);
end
rul = cell2mat(rul);
trueLife = repmat(Life,1,partition.NumTestSets);
trueLife(rul == 0) = 0;
Errors = sum(abs(rul - trueLife),1)./sum(rul ~= 0,1);
mErr = mean(Errors);
sErr = std(Errors);