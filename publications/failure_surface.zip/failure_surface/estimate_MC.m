function [out,info] = estimate_MC(Life,samples,unitIdx,params,config,onlyinfo)
% this function implements the Monte Carlo approximation
% Input:
%   Life   --  Lifetime of each unit
%   samples    --  realizations of gammas
%   unitIdx    --  each sample belongs to which unit?
%   params    --  general path model parameters
%   config    --  configuration information
%   onlyinfo    --  if true, do not fit the model and only generate signal path samples; 
%                   if false, fit the model as well.
% Output:
%   out    --  trained classifier
%   info    --  generated signal path samples

if nargin < 6
    onlyinfo = false;
end

n_unit = length(Life);
D = cell(n_unit,1);
y = cell(n_unit,1);
info.unitIdx = y;
info.sampleIdx = y;
info.Ts = y;
wt = zeros(n_unit,1);
for i=1:n_unit
    ts = getTs(Life(i),config);
    [D{i},tsnew] = getD(samples(:,unitIdx == i),ts,params,true);
    y{i} = double(tsnew >= Life(i));
    info.unitIdx{i} = ones(length(tsnew),1)*i;
    info.Ts{i} = tsnew;
    info.sampleIdx{i} = repelem((1:sum(unitIdx == i))',length(ts));
    if size(info.sampleIdx{i},1) == 1
        info.sampleIdx{i} = info.sampleIdx{i}';
    end
    wt(i) = 1/length(ts);
end
if isfield(config,'weight')
    config.weight = config.weight .* wt;
else
    config.weight = wt;
end
each_length = cellfun(@length,y);
config.weight = repelem(config.weight,each_length);
config.weight = config.weight/sum(config.weight) * length(config.weight);
D = cell2mat(D);
y = cell2mat(y);
info.unitIdx = cell2mat(info.unitIdx);
info.Ts = cell2mat(info.Ts);
info.sampleIdx = cell2mat(info.sampleIdx);

info.D = D;
info.y = y;
info.weight = config.weight;
out = [];
if ~onlyinfo
    out = fitModel(D,y,config);
end