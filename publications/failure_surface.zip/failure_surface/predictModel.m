function prob = predictModel(out,X,config)
% Prediction based on the classifier
% Input:
%   out    --  classifier
%   X    --  predictor
%   config    --  configuration
% Output:
%   prob    --  response, probability of equal to 1

if isfield(config,'select_variable')
    X = X(:,config.select_variable);
end

% predict probability
switch config.classifier
    case 'logistic'
        if isa(out,'GeneralizedLinearModel')
            prob = predict(out,X);
        else
            prob = 1./(1 + exp(-[ones(size(X,1),1),X]*out));
        end
    case 'probit'
        prob = predict(out,X);
    case 'knn'
        [~,prob,~] = predict(out,X);
        prob = prob(:,2);
    case 'nn'
        prob = out(X')';
        prob = prob(:,2);
        assert(all(prob >=0 & prob <=1));
    case 'svm'
        if isa(out,'double')
            prob = sign([ones(size(X,1),1),X] * out);
            prob(prob < 0) = 0;
        else
            [~,~,prob] = svmpredict(ones(size(X,1),1),X,out,'-b 1');
            prob = prob(:,2);
        end
    otherwise
        [~,prob] = predict(out,X);
        prob = prob(:,2);
end