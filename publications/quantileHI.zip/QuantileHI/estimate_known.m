function [wt,obj] = estimate_known(startp,dataset,params,options)
% this function estimate the optimal weight when hyper parameters are known
% Input:
%   startp  --  initial solutions
%   dataset  --  signal data
%   params  --  parameters
%   options  -- options for the optimization algorithm
% Output:
%   wt  --  estimated fusion coefficients
%   obj  --  objective function value

n_sensor = size(dataset.L,2);
nstart = size(startp,2);
[A,b,Aeq,beq,LB,UB,nonlcon] = config_fmincon(dataset,params);
opt_obj = zeros(1,nstart);
opt_wt = zeros(n_sensor,nstart);
for i = 1:nstart % use parfor to speed up
    pause(1);
    x0 = startp(:,i);
    [optx,fval]=fmincon(@(x)qr_hi_obj(x,0,dataset,params)...
        ,x0,A,b,Aeq,beq,LB,UB,nonlcon,options);
    opt_obj(i)=fval;
    opt_wt(:,i) = optx;
end
[~,index]=min(opt_obj);
wt = opt_wt(:,index);
obj = opt_obj(index);