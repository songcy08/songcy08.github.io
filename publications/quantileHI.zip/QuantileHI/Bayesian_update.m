function [mui,Sigmai]=Bayesian_update(ts, hi,params)
% This function calculates the posterior distribution parameters

Psi = design_matrix(ts,params.psi);
Sigmai = inv(Psi'*Psi/params.sigma2 + params.omega);
mui = Sigmai * (Psi'*hi/params.sigma2 + params.omega * params.mu);