function y = qr_hi_obj (x, lambda, dataset, params)
% This function calculate the prediction error + penalty
% Only penalty=0 is considered
% Input:
%   x    --  fusion coefficient
%   lambda    --  penalty weight
%   dataset    --  signal data
%   params    --  all other parameters
% Output:
%   y    --  prediction error + penalty in training set

trh = dataset.L * x;

y=0;
for i=1:max(dataset.Idx)
    idx = dataset.Idx == i;
    [mui,~]=Bayesian_update(dataset.Ts(idx),trh(idx),params);
	Thati = params.rootfun(mui);
    if ~(Thati > 0)
        Thati = 11 * dataset.Life(i);
    end
    if isinf(Thati)
        Thati = 11 * dataset.Life(i);
    end
	y = y + abs(dataset.Life(i) - Thati);
end

y = y + lambda * norm(x,1);