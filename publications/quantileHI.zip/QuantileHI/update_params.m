function newparams = update_params(params,par)
% this function adds the fields of par to params

newparams = params;
newparams.mu = par.mu;
newparams.Sigma = par.Sigma;
newparams.sigma2 = par.sigma2;
newparams.omega = inv(newparams.Sigma);