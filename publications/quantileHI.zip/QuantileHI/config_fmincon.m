function [A,b,Aeq,beq,LB,UB,nonlcon] = config_fmincon(dataset,params)

% This function generates the optimization parameters
% Input:
%   trL    --  L 
%   trIdx    --  a vector specifying each observation belongs to which unit
%   params    --  all parameters
% Output:
%   others    --  required by fmincon

Aeq = []; beq = []; LB = []; UB = [];
assert(isfield(params,'mu'));
assert(isfield(params,'Sigma'));
assert(isfield(params,'l'));
assert(isfield(params,'sigma2'));
[A,b] = linearcon(dataset,params);
nonlcon = @(z) mynonlcon(z,params);