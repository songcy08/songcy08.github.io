clear; clc;
disp('Processing data');
trRaw=dlmread('Engine_sim_data/train_FD001.txt');
trSet.Idx = trRaw(:,1); trSet.Ts = trRaw(:,2); trSet.Raw = trRaw(:,3:end);
trSet.Life = trSet.Ts(diff([trSet.Idx;max(trSet.Idx)+1]) > 0);
tsRaw=dlmread('Engine_sim_data/test_FD001.txt');
tsSet.Idx = tsRaw(:,1); tsSet.Ts = tsRaw(:,2); tsSet.Raw = tsRaw(:,3:end);
tsSet.RUL=dlmread('Engine_sim_data/RUL_FD001.txt');
colnames={'altitudes','Mach','sea-level(temperatures)',...
    'T2','T24','T30','T50','P2','P15','P30','Nf','Nc','epr','Ps30','phi','NRf','NRc',...
    'BPR','farB','htBleed','Nf_dmd','PCNfR_dmd','W31','W32'};

% select sensors
sensor_idx=[5,7,10,11,14,15,16,18,20,23,24]; % these sensors are selected by Liu
trSet.L = trSet.Raw(:,sensor_idx);
tsSet.L = tsSet.Raw(:,sensor_idx);
sensor_trend=[1, 1, -1, 1, 1, -1, 1, 1, 1, -1, -1]; % sensors that have a trend
ntr_units=max(trSet.Idx);
nts_units=max(tsSet.Idx);

% standardize training data
[trSet.L, mu, sigma]=zscore(trSet.L.*repmat(sensor_trend, size(trSet.L,1), 1));
for i=1:ntr_units
    idx = trSet.Idx == i;
    tmp=trSet.L(idx,:);
    tmp=min(tmp,[],1)-exp(tmp(1,:));
    trSet.L(idx,:)=trSet.L(idx,:)-repmat(tmp,sum(idx),1);
end
trSet.L = log(trSet.L);
trSet.L = trSet.L.*repmat(sensor_trend,size(trSet.L,1),1); % trend changes back

% standardize testing data
tsSet.L=(tsSet.L.*repmat(sensor_trend, size(tsSet.L,1),1)...
    -repmat(mu,size(tsSet.L,1),1))./repmat(sigma,size(tsSet.L,1),1);
for i=1:nts_units
    idx = tsSet.Idx == i;
    tmp = tsSet.L(idx,:);
    tmp = min(tmp,[],1)-exp(tmp(1,:));
    tsSet.L(idx,:)=tsSet.L(idx,:)-repmat(tmp,sum(idx),1);
end
tsSet.L = log(tsSet.L);
tsSet.L = tsSet.L.*repmat(sensor_trend, size(tsSet.L,1) ,1);

disp('configuring algorithm');
% Algorithm for 1-norm
% configure the optimization algorithm
config.maxiter = 100;
% configure others
config.nstart = 50;
params.C0 = 1000;
params.C1 = 0.1;
params.C2 = 1e-5;
params.p = 3;
params.psi = [0,1,2];
params.l = 2; % set failure threshold to any positive number
params.rootfun = @(x) max(roots([x(3),x(2),x(1)-params.l]));

options = optimoptions('fmincon','Algorithm','interior-point','Display','off',...
    'MaxIter',50000,'MaxFunEvals',50000,'TolCon',1e-10,'TolFun',1e-6,...
    'TolX',1e-10);
% generate starting points
disp('generating starting points');
params.omega = zeros(params.p); params.mu = zeros(params.p,1); params.sigma2 = 1; params.Sigma = eye(params.p);
rec_startp = random_start(config.nstart,[],trSet,params,true);
rec_init = estimate_known(rec_startp,trSet,params,options); % some rough estimation

startp = random_start(config.nstart,[rec_init,rec_startp],trSet,params,false);
disp('optimization from different start points');
[wt,obj,niter] = estimate_unknown(startp,trSet,params,config.maxiter,options);

trMyHI = trSet.L * wt;
tsMyHI = tsSet.L * wt;

Errors = zeros(max(tsSet.Idx),1);
preds=zeros(nts_units,1);
rld=rldtraining(trMyHI,trSet.Idx, trSet.Ts, params.psi);
for i=1:nts_units
    idx = tsSet.Idx == i;
    preds(i)=rldpredict(tsMyHI(idx),tsSet.Ts(idx),rld,params.l,true);
    Errors(i) = abs(preds(i) - tsSet.RUL(i))/(tsSet.RUL(i) + max(tsSet.Ts(idx)));
end

RULlevels=[max(tsSet.RUL), 100, 80, 60, 40, 20];
Err=zeros(length(RULlevels),size(Errors,2));
for i=1:length(RULlevels)
    idx = tsSet.RUL<=RULlevels(i);
    Err(i,:)=mean(Errors(idx,:));
end