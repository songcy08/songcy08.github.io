function starts = random_start(nstart, user_supply, dataset, params, hyper_known)
% this function generates multiple initial solutions
% Input:
%   nstart  --  number of initial solutions to start with
%   user_supply  --  user specified solutions
%   dataset  --  signal data
%   params  --  general path model parameters
%   hyper_known  --  indicator, whether hyper parameters are known
% Output:
%   starts  --  randomly guessed initial solutions

n_sensor = size(dataset.L,2);
starts = zeros(n_sensor,nstart);

i = 1; q = 1;
while i <= nstart
    pause(0.1);
    if q <= size(user_supply,2)
        x0 = user_supply(:,q);
        q = q+1;
    else
        x0 = 2 * rand(n_sensor,1) - 1;
        x0 = rescale(x0,dataset,params);
    end
    if ~hyper_known
        par = mixef(dataset.L*x0,dataset.Idx,dataset.Ts,params.psi);
        if log10(rcond(par.Sigma)) < -15
            continue;
        end
        params = update_params(params,par);
    end
    [A,b,Aeq,beq,LB,UB,nonlcon] = config_fmincon(dataset,params);
    if any(A*x0 - b>0)
        continue;
    end
    starts(:,i) = x0;
    i = i + 1;
end