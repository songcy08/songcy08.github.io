function [c,ceq]=mynonlcon(x,params)
% this function is the nonlinear constraint on scale of x

c = norm(x,2)-params.C0;
ceq = [];