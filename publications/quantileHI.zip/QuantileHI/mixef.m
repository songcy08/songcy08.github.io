function par = mixef(signals,trIdx,ts,psi)
% This function estimates prior distribution parameters
% Input:
%   signals  --  a vector of signals
%   trIdx  --  corresponding training unit index
%   ts  --  corresponding time points
%   psi  --  basis for polynomial basis
% Output:
%   par  -- estimated prior distribution parameters

p = length(psi);
ntr_units=max(trIdx);
Gamma=zeros(ntr_units, p);
sigma2=zeros(ntr_units,1);
varthetaeps = zeros(p,p,ntr_units);
for i=1:ntr_units
    signal=signals(trIdx==i);
    Psi=design_matrix(ts(trIdx == i),psi);
    Gamma(i,:)= (Psi'*Psi)\(Psi'*signal);
    sigma2(i) = (signal-Psi*Gamma(i,:)')'*(signal-Psi*Gamma(i,:)')/...
        (length(signal)-p);
    varthetaeps(:,:,i) = sigma2(i) * inv(Psi'*Psi);
end

par.mu=mean(Gamma,1)';
Ma = cov(Gamma);
Mb = mean(varthetaeps,3);
[V,D]=eig(Ma,Mb);
if sum(diag(D)>=1) == p
    par.Sigma=Ma - Mb;
elseif sum(diag(D)<1)==p
    par.Sigma = zeros(p,p);
else
    for i=1:size(V,2)
        V(:,i)=V(:,i)/sqrt(V(:,i)'*Mb*V(:,i));
    end
    Theta = inv(V');
    colidx = diag(D)>=1;
    par.Sigma = Theta(:,colidx)*D(colidx,colidx)*Theta(:,colidx)';
end

if rcond(par.Sigma) < 1e-10
    par.Sigma = par.Sigma + eye(p)*1e-5;
end
par.omega = inv(par.Sigma);
par.sigma2=mean(sigma2);
end