function [wt,obj,niter] = estimate_unknown(startp,dataset,params,maxiter,options)
% this function estimate the optimal weight when hyper parameters are unknown
% Input:
%   startp  --  initial solutions
%   dataset  --  signal data
%   params  --  parameters
%   maxiter  --  maximum number of iterations
%   options  -- options for the optimization algorithm
% Output:
%   wt  --  estimated fusion coefficients
%   obj  --  objective function value

n_sensor = size(dataset.L,2);
nstart = size(startp,2);
opt_obj = zeros(1,nstart);
opt_wt = zeros(n_sensor,nstart);
niter = cell(nstart,1);
for i = 1:nstart % use parfor to speed up
    currentWt = startp(:,i);
    lastWt = inf(size(currentWt)); lastObj = inf;
    for iteration = 0:maxiter
        pause(1);
        par = mixef(dataset.L*currentWt,dataset.Idx,dataset.Ts,params.psi);
        tmp_params = update_params(params,par);
        
        [A,b,Aeq,beq,LB,UB,nonlcon] = config_fmincon(dataset,tmp_params);
        if any(A*currentWt > b)
            disp(['start point ',num2str(i),' fails to converge, generate new point']);
            currentWt = random_start(1,[],dataset,tmp_params,false);
            niter{i} = [niter{i};iteration];
            continue;
        end
        
        currentObj = qr_hi_obj(currentWt,0,dataset,tmp_params);
        disp(['start point ',num2str(i),' iteration ',num2str(iteration),...
            ' Decrease in obj ',num2str(lastObj-currentObj)]);
        if abs(lastObj - currentObj) <= options.TolFun && ...
                norm(lastWt - currentWt,2) <= options.TolX
            disp(['start point ',num2str(i),' ends successfully with No of iterations ',num2str(iteration)]);
            break;
        end
        % minimization based on current prior parameters, start point is
        % current estimation of weight
        [optx,~]=fmincon(@(x)qr_hi_obj(x,0,dataset,tmp_params)...
            ,currentWt,A,b,Aeq,beq,LB,UB,nonlcon,options);
        % update the current estimation of weight
        lastWt = currentWt;  currentWt = optx;
        lastObj = currentObj;
    end
    if iteration == maxiter
        disp(['start point ',num2str(i),' exceeds maximum iteration limit of ',num2str(maxiter)]);
    end
    niter{i} = diff([0;niter{i};iteration]);
    opt_obj(i)=currentObj;
    opt_wt(:,i) = currentWt;
end
[~,index]=min(opt_obj);
wt = opt_wt(:,index);
obj = opt_obj(index);