function [A,b] = linearcon(dataset,params)
% Linear constraints Ax <= b
% constraint 1: initial degradation status below failure threshold
% constraint 2: monotonic increasing

nunits = max(dataset.Idx);
% calculate updated variance for each unit
A = zeros( params.p * nunits,size(dataset.L,2));
b = zeros( params.p * nunits,1);
for i=1:max(dataset.Idx)
    Psi = design_matrix(dataset.Ts(dataset.Idx == i)',params.psi);
    Sigmai = inv(Psi'*Psi/params.sigma2 + params.omega);
    Ai = Sigmai * Psi' * dataset.L(dataset.Idx == i,:)/params.sigma2;
    bi = Sigmai * params.omega * params.mu;
    bi(1) = -bi(1) + params.l - params.C1; % constraint 2
    Ai(2:end,:) = -Ai(2:end,:);
    bi(2:end) = bi(2:end) - params.C2; % constraint on monotonicity
    A( params.p*(i-1)+1 : params.p*i, :) = Ai;
    b( params.p*(i-1)+1 : params.p*i, :) = bi;
end