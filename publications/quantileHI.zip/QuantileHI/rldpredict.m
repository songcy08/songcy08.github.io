function y=rldpredict(signal,ts, rld,fthres,returnRUL)
% This function implement the in-situ RLD model proposed by Gebraeel,
% predict the remaining life in testing data

% Input:
%   signals    --  a column vector, the signal sequence for one sensor one
%                  unit
%   ts    --  corresponding time points
%   rld    --  a structure containing parameters of the model
%   fthres    --  failure threshold
%   returnRUL    --  True/False indicator, whether return RUL or failure time
% Output:
%   y    --  a number specifying the RUL or failure time of the unit
if nargin < 5
    returnRUL = true;
end
ni=length(signal);
Psi=design_matrix(ts,rld.psi);

ci = (ts - ts(1))/(ts(end)-ts(1)) * 0.98 + 0.01;
ci = diag(sqrt(ci/sum(ci)*ni));
    
% variance of the posterior distribution of Gamma
post_sigma=inv(Psi'*ci*ci*Psi/rld.sigma2+inv(rld.Sigma));
% mean of posterior distribution of Gamma
post_mu=post_sigma * (Psi' * ci * ci* signal/rld.sigma2 + rld.Sigma\rld.mu);
t=(0:300)';
gt=g(t,max(ts),post_mu,post_sigma,rld,fthres);
Pt=(normcdf(gt)-normcdf(gt(1)))/(1-normcdf(gt(1)));
[~, ind]=min(abs(Pt-0.5));
y=t(ind);
if ~returnRUL
    y = y + ts(end);
end
% y=y+1; % I think this line is not necessary
end

function y=g(t, tni, mu, sigma, rld,fthres)
% this function calculate g-function in the paper
% Input:
%   t    --  a column vector, the time beyond the last observation
%   ni    --  an integer, time of the last observation
%   mu    --  posterior mean of the polynomial coefficients
%   sigma    --  posterior variance of the polynomial coefficients
%   rld    --  parameter of the training model
% Output:
%   y    --  value of g(t), a column vector
Psi=design_matrix(t+tni,rld.psi);
pred_mu=Psi * mu;
pred_sigma=sum(Psi * sigma .* Psi, 2);
y=(pred_mu - fthres)./sqrt(pred_sigma);
y=y*rld.trend;
end