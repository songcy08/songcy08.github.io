function rld = rldtraining( signals, idx, ts, psi )
% This function implement the in-situ RLD model proposed by Gebraeel,
% estimating the essential parameters in the training data

% Input:
%   signals    --  a column vector, the concatenated signal sequence from multiple units
%   idx    --  a column vector of same length as signals, specifying the
%                  which unit a value in signals corresponds to
%   ts    --  corresponding time points
%   psi    --  polynomial basis
% Output:
%   rld    --  a structure containing parameters of the model

p = length(psi);
n_unit=max(idx);
Gamma=zeros(n_unit, p);
noisevar=zeros(n_unit,1);
varthetaeps = zeros(p,p,n_unit);
for i=1:n_unit
    signal=signals(idx==i);
    Psi=design_matrix(ts(idx==i),psi);
    Gamma(i,:)=wtlm(Psi,signal,ts(idx==i))';
    singlenoise=signal-Psi*Gamma(i,:)';
    noisevar(i)=sum(singlenoise.^2)/(length(signal)-p);
    varthetaeps(:,:,i) = noisevar(i) * inv(Psi'*Psi);
end

rld.mu=mean(Gamma,1)';
Ma = cov(Gamma);
Mb = mean(varthetaeps,3);
[V,D]=eig(Ma,Mb);
if sum(diag(D)>=1)==p
    rld.Sigma=Ma - Mb;
elseif sum(diag(D)<1)==p
    rld.Sigma = zeros(p,p);
else
    for i=1:size(V,2)
        V(:,i)=V(:,i)/sqrt(V(:,i)'*Mb*V(:,i));
    end
    Theta = inv(V');
    colidx = diag(D)>=1;
    rld.Sigma = Theta(:,colidx)*D(colidx,colidx)*Theta(:,colidx)';
end
rld.psi = psi;
rld.sigma2=mean(noisevar);
rld.trend=sign(rld.mu(end));
end

