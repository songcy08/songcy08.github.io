function new_wts = rescale(wts,dataset,params)
% Rescale the fusion coefficients
% Input:
%   wts  --  fusion coefficients to rescale
%   dataset  --  signal dataset
%   params  --  general path model parameters
% Output:
%   new_wts  --  scaled fusion coefficients

new_wts = wts;
for j = 1:size(wts,2)
    hi = dataset.L * wts(:,j);
    lastIdx = find(diff([dataset.Idx;max(dataset.Idx)+1]) > 0);
    ratio = params.l/mean(hi(lastIdx));
    new_wts(:,j) = wts(:,j) * ratio;
end