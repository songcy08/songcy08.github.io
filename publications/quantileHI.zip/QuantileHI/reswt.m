function c=reswt(ts)
% Set the weight of each time point

r = (ts - ts(1))/(ts(end)-ts(1));
c = r * 0.98 + 0.01;
c=c/sum(c);
c=sqrt(c);
c=diag(c);